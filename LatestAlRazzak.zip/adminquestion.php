<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>
<?php
    include_once 'connect.php';
    @include('includeFile/header.php');
    ch_title("Admin Question");
?>

<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
</a>

 <!-- Start menu -->
<?php
    @include('includeFile/admin_navbar.php')
?>

<section id="mu-course-content" style="background-color: white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   
                        <?php
                            @$id=$_GET['id'];
                            //$query=mysqli_query($con,"select subject_name from subject where id='$id'");\
                            $query=mysqli_query($con,"select academic.* , subject.*,chapter.* ,topic.* from academic inner join subject on academic.id = subject.academy_id inner join chapter on subject.id = chapter.subject_id inner join topic on chapter.id = topic.chapter_id where topic.id='$id'");
                            $row=mysqli_fetch_assoc($query);
                            echo '
                                    <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Moke Test</h1>
                                    <h1 style="font-family: Arial, Helvetica, sans-serif;"><a href="adminacademic.php">Academic></a>'.$row['academic_name'].'><a href="adminsubject.php?id='.$row['academy_id'].'">Subject</a>>'.$row['subject_name'].'><a href="adminchapter.php?id='.$row['subject_id'].'"Chapter>'.$row['chapter_name'].'><a href="admintopic.php?id='.$row['id'].'">'.$row['topic_name'].'</a>>Question</h1>

                                    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                        <hr>
                                    </div>
                                    ';
                        ?>
                                            
                </div>
                        <div class="col-md-6 col-sm-6">
                            <form method="POST" action="phpScript/moke_question_script.php">
                                <ol class="cs">
                                    <?php
                                        if(@$_GET['response'] != ''){
                                            echo ' <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }
                                        echo '<h1 class="text-center">Question</h1>';
                                        @$id=$_GET['id'];
                                        $a=1;
                                        echo '<select class="form-control" name="job_title" id="job_title">
                                                                <option></option>';
                                                    $query1=mysqli_query($con,"select * from moke_title");
                                                    if (mysqli_num_rows($query1) > 0) {
                                                        while($row1=mysqli_fetch_assoc($query1)){
                                                            echo'<option value="'.$row1['id'].'">'.$row1['job_title'].'</option>';
                                                        }
                                                    }
                                                    else {
                                                        header("location: addmoke.php?response=error&class=danger&message=First Add moke Test");
                                                    }
                                                       
                                        echo '</select>';    
                                        $query=mysqli_query($con,"select * from question where topic_id='$id' and status='inactive'");
                                        while($row=mysqli_fetch_assoc($query)){
                                            echo '<li>
                                                        <input type="checkbox" name="checkbox[]" value="'.$row['id'].'"> <h1 style="margin-left:4%; margin-top:-8%;" name="question">'.$row['question'].'</h1>
                                                        <input type="hidden" name="id" value="'.$row['topic_id'].'"/>
                                                        
                                                </li>';
                                        } 
                                        echo '<input type="hidden" name="time"  id="time"/>';
                                    ?>
                                </ol> 
                                <input type="submit" class="btn btn-primary" style="margin-left: 5%;"  name="submit" value="Add" >
                            </form>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <ul class="cs">
                                <?php
                                echo '<h1 class="text-center">Subject</h1>'; 
                                $query=mysqli_query($con,"select * from academic ");
                                while($row=mysqli_fetch_assoc($query)){
                                    echo '<li><a href= "adminsubject.php?id='.$row['id'].'" >'.$row['academic_name'].'</a></li>';
                                }
                                ?>
                            </ul>
                                        
                        </div>
                </div>
            </div>
        </div>
    </section>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type="text/javascript">
   $(document).ready(function(e){
        
        $('#job_title').on('change', function(e){
            //console.log(e);
            var job_title = e.target.value;
            //console.log(job_ads_id);
            $.get('ajax/mokeServer.php?id='+job_title, function(data){
                //console.log(data);
                var result = JSON.parse(data);
                //console.log(result);
                 //$('#subject').empty();  
                 for(var i=0 ;i<result.length ; i++ ){
                     //console.log(result[i].id);
                     //$('#subject').append('<option value = "'+result[i].id+'">'+result[i].subject_name+'</option>');
                    $('#time').val(result[i].time);
                    
                 }
            });
        });
    });
</script>

<?php 
    @include('includeFile/footer.php')
?>