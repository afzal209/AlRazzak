<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
} 
?>

<?php
include_once 'includeFile/header.php';
ch_title("Add Job");
include_once 'includeFile/admin_navbar.php';
?>

<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Add Organization</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="phpScript/job_ads_script.php" enctype="multipart/form-data">
                                        <?php 
                                        if(@$_GET['response1'] != ''){
                                    echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response1']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }
                                           
                                        ?>
                                      
                                        <p class="comment-form-author">
                                            <label for="image">Choose Image <span class="required">*</span></label>
                                            <input type="file"   value="" name="image_logo">
                                        </p> 
                                        <p class="comment-form-author">
                                            <label for="organization">Organization</label>
                                            <input type="text" name="organization" id="organization">
                                        </p>
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit_Organization">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- end contact content -->
                </div>  
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Add Job</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="phpScript/job_ads_script.php" enctype="multipart/form-data">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                    echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }
                                            $timezone = "Asia/Karachi";
                                            date_default_timezone_set($timezone);
                                            //$today = date("d/m/y h:i:sa");
                                            $today = date("d-M-Y l");
                                        ?>
                                        <p class="comment-form-author">
                                                <label for="choose_organization">Type <span class="required">*</span></label>
                                                <select class="form-control"  name="choose_organization" id="choose_organization">
                                                    <option value=""></option>
                                                    <?php 
                                                    $query = mysqli_query($con,"select * from organization");
                                                    while($row=mysqli_fetch_assoc($query)){
                                                        echo '<option value="'.$row['id'].'">'.$row['organization_name'].'</option>';
                                                    }
                                                    ?>
                                                </select>
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="image">Choose Image <span class="required">*</span></label>
                                            <input type="file"   value="" name="image">
                                        </p>    
                                        <p class="comment-form-author">
                                            <label for="job_title"> Job Title</label>
                                            <input type="text" name="job_title" id="job_title">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="content">Content</label>
                                            <textarea  aria-required="true" rows="8" cols="45" name="content" id="content"></textarea>
                                        </p> 
                                        <!-- <p class="comment-form-author">
                                            <label for="city">City</label>
                                            <input type="text" name="city" id="city">
                                        </p> -->
                                        <!-- <p class="comment-form-author">
                                            <label for="provinces">Provinces</label>
                                            <input type="text" name="provinces" id="provinces">
                                        </p> -->
                                        <p class="comment-form-author">
                                            <label for="issue_date">Issue Date</label>
                                            <input type="text" value="<?php echo $today;?>" name="issue_date" id="issue_date" >
                                        </p>
                                        <!-- <p class="comment-form-author">
                                            <label for="last_date">Last Date</label>
                                            <input type="text" name="last_date" id="last_date">
                                        </p> -->
                                        <p class="comment-form-author">
                                            <label for="source">Source</label>
                                            <input type="text" name="source" id="source">
                                        </p>
                                        <!-- <p class="comment-form-author">
                                            <label for="categories">Categories</label>
                                            <input type="text" name="categories" id="categories">
                                        </p>      -->
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- end contact content -->
                </div>
            </div>
        </div>
    </div>
    
</section>


<?php
include('includeFile/footer.php')
?>