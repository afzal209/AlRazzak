<?php
include_once 'connect.php';
@include('includeFile/header.php');
ch_title("Subject");
?>

    <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- END SCROLL TOP BUTTON -->

    <!-- Start header  -->

    <!-- End header  -->
    <!-- Start menu -->
    <?php
    include_once 'includeFile/admin_navbar.php';
     ?>
    <!-- End menu -->
    <!-- Start search box -->
    
    <!-- End search box -->
    <!-- Page breadcrumb -->
    <!-- <section id="mu-page-breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mu-page-breadcrumb-area">
                        <h2>Course</h2>
                        <ol class="breadcrumb">
                            <li><a href="#">Home</a></li>
                            <li class="active">Course</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- End breadcrumb -->
    <section id="mu-course-content" style="background-color: white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mu-course-content-area">
                        <div class="row">
                            <div class="col-md-9">
                                <!-- start course content container -->
                                <div class="mu-course-container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <?php
                                                  @$id=$_GET['id'];
                                                  $query=mysqli_query($con,"select academic_name from academic where id ='$id' ");
                                                  $row=mysqli_fetch_assoc($query);
                                                  echo '<h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">'.$row['academic_name'].'</h1>
                                                        <h1 style="font-family: Arial, Helvetica, sans-serif;">Subject</h1>';
                                            ?>
                                            
                                        </div>
                                            <?php
                                        //   if(isset($_GET['page'])){
                                        //         @$page = $_GET['page'];
                                        //     }
                                        //     else{
                                        //         $page = 1;
                                        //     }
                                        //     $num_per_page = 04;
                                        //     $start_from = ($page-1)*04;
                                            @$id=$_GET['id'];  
                                            $query=mysqli_query($con,"select * from subject where academy_id ='$id' ");
                                            if(mysqli_num_rows($query) > 0){
                                                while($row=mysqli_fetch_array($query)){ 
                                                
                                               echo' <div class="col-md-6 col-sm-6">
                                                    <div class="mu-latest-course-single">
                                                        <figure class="mu-latest-course-img">
        
                                                            <a href=""><img src="image/'. $row['subject_image'].'" alt="img" width="350" height="300" ></a>
                                                            
                                                        </figure>
                                                        <div class="mu-latest-course-single-content">
                                                            <h4 id="txt"><a href="chapters.php?id='.$row['id'].'"> '.$row['subject_name'].'</a></h4>
                                                           
                                                        </div>
                                                    </div>
                                                </div>';
                                            
                                            }
                                        }
                                        else{
                                            echo 'No Subject Found';
                                        }
                                        ?>
                                    </div>
                                </div>
                                <!-- end course content container -->
                                <!-- start course pagination -->
                                <!--<div class="mu-pagination">-->
                                <!--    <nav>-->
                                <!--        <ul class="pagination">-->
                                            <?php 
                                                //  @$id=$_GET['id'];
                                                //  $a=1;
                                                //  $pr_query=mysqli_query($con,"select * from subject where academy_id ='$id'");
                                                //  $total_num= mysqli_num_rows($pr_query);
                                                //  //echo $total_num;
                                                //  $total_page = ceil($total_num/$num_per_page);
                                                //  //echo $total_page; 
                                                  
                                                    
                                                //         if($page>1){
                                                //             echo'<li>
                                                //                     <a href="subject.php?page='.($page - 1).'&id='.$id.'" aria-label="Previous">
                                                //                         <span class="fa fa-angle-left"></span> Prev
                                                //                     </a>
                                                //                 </li>';
                                                //         }
                                                //         for ($i=1; $i<=$total_page ; $i++) {
                                                //             echo '<li><a href="subject.php?page='.$i.'&id='.$id.'">'.$i.'</a></li>';
                                                //         }
                                                //         if($i>$page){
                                                //             echo '<li>
                                                //                 <a href="subject.php?page='.($page + 1).'&id='.$id.'" aria-label="Next">
                                                //                     Next <span class="fa fa-angle-right"></span>
                                                //                 </a>
                                                //             </li>';
                                                //         }
                                            ?>
                                <!--        </ul>-->
                                <!--    </nav>-->
                                <!--</div>-->
                                <!-- end course pagination -->
                            </div>
                            <div class="col-md-3">
                                <!-- start sidebar -->
                                <aside class="mu-sidebar">
                                    <!-- start single sidebar -->
                                    <div class="mu-single-sidebar">
                                        <h3>Categories</h3>
                                        <ul class="mu-sidebar-catg">
                                             <?php
                                               $insert_type = $_GET['insert_type'];
                                               $query=mysqli_query($con,"select * from academic where insert_type = '$insert_type'");
                                                while($row=mysqli_fetch_array($query)){ 
                                                ?>
                                            <li><a href="subject.php?id=<?php echo $row['id'];?>&insert_type=<?php echo $row['insert_type']?>"><?php echo $row['academic_name']?></a></li>
                                            <?php
                                                }
                                            ?>
                                        </ul>
                                    </div>
                                    <!-- end single sidebar -->
                                    <!-- start single sidebar -->
                                   
                                    <!-- end single sidebar -->
                                    <!-- start single sidebar -->
                                    
                                    <!-- end single sidebar -->
                                    <!-- start single sidebar -->
                                 
                                    <!-- end single sidebar -->
                                </aside>
                                <!-- / end sidebar -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Start footer -->
    <?php 
    @include('includeFile/footer.php')
    ?>