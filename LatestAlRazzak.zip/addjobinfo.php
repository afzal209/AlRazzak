<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
} 
?>

<?php
include_once 'includeFile/header.php';
ch_title("Add Job Info");
include_once 'includeFile/admin_navbar.php';
?>

<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Add Job Info</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="phpScript/job_ads_info_script.php" enctype="multipart/form-data">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                    echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }
                                        $timezone = "Asia/Karachi";
                                            date_default_timezone_set($timezone);
                                            //$today = date("d/m/y h:i:sa");
                                            $today = date("d-M-Y l");
                                           
                                        ?>
                                      <p class="comment-form-author">
                                                <label for="organization_name">Choose Organization <span class="required">*</span></label>
                                                <select class="form-control"  name="organization_name" id="organization_name">
                                                    <option value=""></option>
                                                    <?php 
                                                    $query = mysqli_query($con,"select * from organization");
                                                    while($row=mysqli_fetch_assoc($query)){
                                                        echo '<option value="'.$row['id'].'">'.$row['organization_name'].'</option>';
                                                    }
                                                    ?>
                                                </select>
                                        </p>
                                      
                                      <p class="comment-form-author">
                                                <label for="job_ads">Choose Title <span class="required">*</span></label>
                                                <select class="form-control"  name="job_ads" id="job_ads">
                                                    <option value=""></option>
                                                    <?php 
                                                    // $query = mysqli_query($con,"select * from job_ads");
                                                    // while($row=mysqli_fetch_assoc($query)){
                                                    //     echo '<option value="'.$row['id'].'">'.$row['job_title'].'</option>';
                                                    // }
                                                    ?>
                                                    
                                                </select>
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="no_of_post">No of Job</label>
                                            <input type="number" name="no_of_post" id="no_of_post">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="department">Department</label>
                                            <input type="text" name="department" id="department">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="quota">Quota</label>
                                            <input type="text" name="quota" id="quota" placeholder="Number (urban) Number (rural)">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="job_designaiton">Job Designaiton</label>
                                            <input type="text" name="job_designaiton" id="job_designaiton">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="city">City</label>
                                            <input type="text" name="city" id="city">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="provinces">Provinces</label>
                                            <input type="text" name="provinces" id="provinces">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="issue_date">Issue Date</label>
                                            <input type="text" name="issue_date" id="issue_date" readonly>
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="last_date">Last Date</label>
                                            <input type="text" name="last_date" id="last_date">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="source">Source</label>
                                            <input type="text" name="source" id="source" readonly>
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="categories">Categories</label>
                                            <input type="text" name="categories" id="categories">
                                        </p>
                                        
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- end contact content -->
                </div>  
              
            </div>
        </div>
    </div>
    
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type="text/javascript">
   $(document).ready(function(e){
        $('#organization_name').on('change', function(e){
            //console.log(e);
            var organization_name = e.target.value;
            //console.log(job_ads_id);
            $.get('ajax/organizationServer.php?id='+organization_name, function(data){
                //console.log(data);
                var result = JSON.parse(data);
                //console.log(result);
                 $('#job_ads').empty();  
                 $('#job_ads').append('<option value = ""></option>');
                 for(var i=0 ;i<result.length ; i++ ){
                     //console.log(result[i].id);
                     $('#job_ads').append('<option value = "'+result[i].id+'">'+result[i].job_title+'</option>');
                    // $('#issue_date').val(result[i].issue_date);
                    // $('#source').val(result[i].source)
                 }
            });
        })
        $('#job_ads').on('change', function(e){
            //console.log(e);
            var job_ads_id = e.target.value;
            //console.log(job_ads_id);
            $.get('ajax/jobServer.php?id='+job_ads_id, function(data){
                //console.log(data);
                var result = JSON.parse(data);
                //console.log(result);
                 //$('#subject').empty();  
                 for(var i=0 ;i<result.length ; i++ ){
                     //console.log(result[i].id);
                     //$('#subject').append('<option value = "'+result[i].id+'">'+result[i].subject_name+'</option>');
                    $('#issue_date').val(result[i].issue_date);
                    $('#source').val(result[i].source)
                 }
            });
        });
    });
</script>

<?php
include('includeFile/footer.php')
?>