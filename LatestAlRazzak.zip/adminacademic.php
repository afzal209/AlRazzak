<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>
<?php
    
    
    @include('includeFile/header.php');
    ch_title("Admin Academic");
?>

<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
</a>

 <!-- Start menu -->
<?php
    @include('includeFile/admin_navbar.php')
?>

<section id="mu-course-content" style="background-color: white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   
                        <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Moke Test</h1>
                                  <h1 style="font-family: Arial, Helvetica, sans-serif;">Academics</h1>
                       
                                            
                </div>
                        <div class="col-md-12 col-sm-12">
                            <ol class="cs">
                                <?php
                                  
                                    $query=mysqli_query($con,"select * from academic ");
                                    while($row=mysqli_fetch_assoc($query)){
                                        echo '<li><a href= "adminsubject.php?id='.$row['id'].'" >'.$row['academic_name'].'</a></li>';
                                    } 
                                ?>
                            </ol>
                        </div>
                </div>
            </div>
        </div>
    </section>




<?php 
    @include('includeFile/footer.php')
?>