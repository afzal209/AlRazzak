<?php 
// session_start();
// session_destroy();

$id= $_GET['id'];
header('location:subject.php?id='.$id);

exist();
?>