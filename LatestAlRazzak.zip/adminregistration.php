<?php 
include('connect.php');

$select=mysqli_query($con,"select * from user");
if(mysqli_num_rows($select) == 0) {
?>
<?php
include_once 'includeFile/header.php';
ch_title("Admin Registration");
include_once 'includeFile/admin_navbar.php';
?>

<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Admin Registration</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="phpScript/admin_script.php">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                    echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }

                                        ?>
                                         <p class="comment-form-author">
                                            <label for="username">Username <span class="required">*</span></label>
                                            <input type="text"   value="" name="username">
                                        
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="email">Email <span class="required">*</span></label>
                                            <input type="email" value="" name="email">
                                        
                                        </p>
                                        <p class="comment-form-email">
                                            <label for="password"> Password <span class="required">*</span></label>
                                            <input type="password"   value="" name="password" style="width: 100%; height: 35px;">
                                       </p>
                                            
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                        </p> 
                                       
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>

<?php
include('includeFile/footer.php')
?>

<?php
}
else{
    header("location:login.php");
}
?>