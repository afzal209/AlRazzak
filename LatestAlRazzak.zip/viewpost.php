<?php
include_once 'connect.php';


?>
 <head>
     <title>AlRazzak | View Post</title>
     <?php
     @include_once 'includeFile/css.php';
     @include_once 'includeFile/script.php';
     
     ?>
 </head>
   
    <section id="mu-course-content" style="background-color: white; padding: 18px 0;">
        <div class="container">
            <div class="row">
            <?php
            $id = $_GET['id'];
            $query = mysqli_query($con,"select * from job_ads where id = '$id'");
            while($row=mysqli_fetch_assoc($query)){
                echo'<div class="col-md-12">
                        <h1  style="font-family: Arial, Helvetica, sans-serif;">'.$row['job_title'].'</h1>
                    </div>
                    <div class="col-md-12">
                        <image src="ads_pic/'.$row['image'].'" width="100%" height="100%">
                    </div>
                ';
            } 
            ?>    
                
            </div>
        </div>
    </section>
    

