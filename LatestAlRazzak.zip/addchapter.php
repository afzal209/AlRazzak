<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>
<?php
    
    //  $session_permission = $_SESSION['user']['academic_id'];
    // // //echo $session_var;
    // // $session_permission = explode(',' ,$session_permission);
    // //echo '<pre>'.print_r($session_permission,true).'</pre>';
    //  $session_permission = implode("','",$session_permission);
    // //echo '<pre>'.print_r($session_permission,true).'</pre>';

    // // //echo $session_permission;
    // $where = "";
    // if($_SESSION['user']['role'] == 'editor'){
    //     $where = "where id IN ($session_permission)";
    // }
    // $query=mysqli_query($con,"select * from academic $where");
    // $resultAcademics = array();
    // while($row=mysqli_fetch_assoc($query)){
    //     $resultAcademics[] = $row;
    // }
    //echo '<pre>'.print_r($resultAcademics,true).'</pre>';
?>
<?php
include_once 'includeFile/header.php';
ch_title("Add Chapter");
include_once 'includeFile/admin_navbar.php';
?>

<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Add Chapter</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="phpScript/chapter_script.php" enctype="multipart/form-data">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                             echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }

                                        ?>
                                         <p class="comment-form-email">
                                            <label for="academicname">Choose Academic<span class="required">*</span></label>
                                            <select class="form-control"  name="academic" id="academic">
                                                <option value=""></option>

                                            <?php 
                                                    $query = mysqli_query($con,"select * from academic");
                                                    if(mysqli_num_rows($query) > 0){
                                                        while($row=mysqli_fetch_assoc($query)){
                                                    echo '<option value="'.$row['id'].'" > '.$row['academic_name'].' </option>';
                                                        }                                          
                                                    }
                                                    else{
                                                        echo '<option>No academic Add</option>';
                                                    }
                                            ?>
                                            </select>
                                        </p>
                                        <p class="">
                                            <label for="author">Choose Subject <span class="required">*</span></label>
                                           
                                            <select name="subject" id="subject" class="form-control">
                                                <option value=""></option>
                                            </select>
                                        </p>
                                         <p class="comment-form-author">
                                            <label for="name">Chapter Name <span class="required">*</span></label>
                                            <input type="text"  size="30" value="" name="name">
                                        </p>
                                        
                                        <input type="hidden" name="insert_by" value="<?php echo @$_SESSION['user']['username']; ?>" >             
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type="text/javascript">
    $(document).ready(function(e){
        $('#academic').on('change', function(e){
            //console.log(e);
            var aca_id = e.target.value;
            //console.log(aca_id);
            $.get('ajax/chapterServer.php?id='+aca_id, function(data){
                //console.log(data);
                var result = JSON.parse(data);
                //console.log(result);
                 $('#subject').empty();  
                 for(var i=0 ;i<result.length ; i++ ){
                     //console.log(result[i].id);
                     $('#subject').append('<option value = "'+result[i].id+'">'+result[i].subject_name+'</option>');
                 }
            });
        });
    });
</script>
<?php
include('includeFile/footer.php')
?>
