<?php

if(isset($_POST['submit'])){
    include('../connect.php');

    if(empty($_POST['checkbox']) ){

        header('location:../adminquestion.php?response=error&class=danger&message=Please fill the Record');

    }
    else{
        $id=$_POST['id'];
        $checkbox=$_POST['checkbox'];
        $job=$_POST['job_title'];
        $time = $_POST['time'];
        $timezone = "Asia/Karachi";
        date_default_timezone_set($timezone);
        $today = date("d/m/y");
        
        for($i=0 ; $i<sizeof($checkbox); $i++){
            $query=mysqli_query($con,"insert into questions_meta(date,question_id,meta_key,meta_value,time) values('$today','$checkbox[$i]','job_type','$job','$time')");
            if($query){
                $update=mysqli_query($con,"update question set status = 'active' where id= '$checkbox[$i]'");
                if($update){
                    header('location:../adminquestion.php?id='.$id);
                }   
            }
            else{
                echo 'error';
            }
        }
    }
} 

?>