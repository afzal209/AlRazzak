<?php

if(isset($_POST['submit'])){
    include('../connect.php');

    if( empty($_POST['job_title']) ){
        header('location:../addmoke.php?response=error&class=danger&message=All fields are mandatory.');
    }
    else{
        $job_title=$_POST['job_title'];
        $date=$_POST['date'];
        $time=$_POST['time'];

        // echo '<pre>';
        // print_r($job_title .'+'. $date .'+'. $time);
         $query=mysqli_query($con,"insert into moke_title(job_title,date,time) values('$job_title','$date','$time')");
        //print_r($query)
         if($query){
            header('location:../adminacademic.php');
        }
        else {
            echo 'error';
        }
    }
}


?>