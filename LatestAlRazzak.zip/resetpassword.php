




<?php

include_once 'header.php';

ch_title("Reset Password");

include_once 'admin_navbar.php';

?>

	

<section id="mu-contact" style="background-color: white">

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <div class="mu-contact-area">

                    <!-- start title -->

                    <div class="mu-title">

                        <h2>Reset Password</h2>

                    </div>

                    <!-- end title -->

                    <!-- start contact content -->

                

                    <div class="mu-contact-content" >           

                        <div class="row">

                            <div class="col-md-6">

                                <div class="mu-contact-left" >
                                	<?php
									if(isset($_GET['email']) && isset($_GET['token'])){
									    include('connect.php');
									    $email=$_GET['email'];
									    $token=$_GET['token'];
									 	$select=mysqli_query($con,"select id from user where email='$email' and token='$token'");

									    

									    if(mysqli_num_rows($select) > 0){
									   ?> 
									   	<form class="contactform" method="post" action="resetpassword_script.php">
                                        <?php 

                                        if(@$_GET['response'] != ''){

                                    echo '  <div class="alert alert-'.@$_GET['class'].'">

                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'

                                            </div>';

                                        }



                                        ?>

                                        

                                                

                                        <p class="comment-form-email">

                                            <label for="password">New Password <span class="required">*</span></label>

                                            <input type="password"   value="" name="newpassword" style="width: 100%; height: 35px;">

                                        </p>
                                        <p class="comment-form-email">

                                            <label for="password">Confirm Password <span class="required">*</span></label>

                                            <input type="password"   value="" name="confirmpassword" style="width: 100%; height: 35px;">

                                        </p>     
                                        <input type="hidden" name="email" value="<?php echo $email; ?>">
                                        <input type="hidden" name="token" value="<?php echo $token; ?>">
                                        <p class="form-submit">

                                            <input type="submit" value="Login" class="mu-post-btn" name="submit">

                                        </p>  

                                    </form>
									<?php

									    }

									    else {

									        header('location: forgetpassword.php?response=error&class=danger&message=Link expired');

									    } 

									}

									else {

									    header("location: login.php");
									    exit();

									}

									?>



                                </div>

                            </div>

                    </div>

                </div>

                <!-- end contact content -->

            </div>

        </div>

    </div>

    

</section>



	

<?php

include('footer.php')

?>



