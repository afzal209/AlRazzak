<?php
include_once 'connect.php';
@include('includeFile/header.php');

ch_title("Score Board");
?>
<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
    </a>
    
    <?php
        @include_once 'includeFile/admin_navbar.php';
    ?>
    <section id="mu-course-content" style="background-color: white; padding: 18px 0;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Score Board</h1>
                    <div class="row">
                       
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-top: 5px;">
                       
                            <div  class="col-md-12 col-sm-12 table-responsive" style="margin-top:2%;">
                                    <table class="table table-bordered  table-striped">
                                        <tr>
                                            <th>User Name</th>
                                            <th>Correct Answer</th>
                                            <th>Wrong Answer</th>
                                            <th>Total Question</th>
                                            <th>Percentage</th>
                                        </tr>
                                        <?php
                                        $id= $_GET['id'];
                                        $query = mysqli_query($con,"select social_users.first_name, moke_score.*  ,count(moke_score.right_wrong) as r from social_users left join moke_score on social_users.id = moke_score.social_user_id where moke_score.paper_id ='$id' and right_wrong ='right'  ");
                                        $query_w = mysqli_query($con,"select social_users.first_name, moke_score.* ,count(moke_score.right_wrong) as w   from social_users left join moke_score on social_users.id = moke_score.social_user_id where moke_score.paper_id ='$id' and right_wrong ='wrong'  ");
                                        $query_p = mysqli_query($con,"select social_users.first_name, moke_score.* ,count(moke_score.paper_id) as p   from social_users left join moke_score on social_users.id = moke_score.social_user_id where moke_score.paper_id ='$id'");

                                        while($row=mysqli_fetch_assoc($query)){
                                            while ($row_w=mysqli_fetch_assoc($query_w)) {
                                                while ($row_p=mysqli_fetch_assoc($query_p)) {
                                                    $mark = $row['r'];
                                                    $total = $row_p['p'];
                                                    echo'<tr>
                                                        <td>'.$row['first_name'].'</td>
                                                        <td>'.$row['r'].'</td>  
                                                        <td>'.$row_w['w'].'</td> 
                                                        <td>'.$row_p['p'].'</td>
                                                        <td>'.($mark/100)*$total.'</td>
                                                    </tr>';

                                                }
                                            }
                                   
                                        }
                                        ?>
                                 </table>
                            </div>
                         
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
<?php    
    include('includeFile/footer.php');
?>
