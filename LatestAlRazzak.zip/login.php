<?php 
include_once 'connect.php';
    if(isset($_SESSION['user']['email'])){
        header('location: dashboard.php');
    }
    if(@$_GET['show_array'] == 1){
        echo '<pre>'.print_r($_SESSION,true).'</pre>';
    }

    
?>

<?php
include_once 'includeFile/header.php';
ch_title("Login");
include_once 'includeFile/admin_navbar.php';
?>

<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Login</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="phpScript/login_script.php">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                    echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }

                                        ?>
                                        <p class="comment-form-author">
                                            <label for="email">Email <span class="required">*</span></label>
                                            <input type="email"   value="" name="email">
                                        
                                        </p>
                                        <p class="comment-form-email">
                                            <label for="password">Password <span class="required">*</span></label>
                                            <input type="password"   value="" name="password" style="width: 100%; height: 35px;">
                                        
                                        </p>         
                                        <p class="form-submit">
                                            <input type="submit" value="Login" class="mu-post-btn" name="submit">
                                            <?php
                                                $query=mysqli_query($con,"select * from user");
                                                if(mysqli_num_rows($query) == 0){
                                                  echo '<a href="adminregistration.php">Admin Registration</a>';  
                                                } 
                                            ?>
                                        </p> 
                                            <a href="forgetpassword.php">Forget Password</a>  
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>


<?php
include('includeFile/footer.php')
?>

<?php

    

?>