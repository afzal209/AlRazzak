<?php
include_once 'connect.php';

@include('includeFile/header.php');

ch_title("Prepare Topic");
?>

    <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- END SCROLL TOP BUTTON -->

    <!-- Start header  -->

    <!-- End header  -->
    <!-- Start menu -->
    <?php
   include_once 'includeFile/admin_navbar.php';
     ?>
    <!-- End menu -->
    <!-- Start search box -->
    
    <!-- End search box -->
    <!-- Page breadcrumb -->
    <!-- <section id="mu-page-breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mu-page-breadcrumb-area">
                        <h2>Course</h2>
                        <ol class="breadcrumb">
                            <li><a href="#">Home</a></li>
                            <li class="active">Course</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- End breadcrumb -->
    <section id="mu-course-content" style="background-color: white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mu-course-content-area">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- start course content container -->
                                <div class="mu-course-container ">
                                    <div class="row">
                                    <?php
                                        $id=$_GET['id'];
                                        $query=mysqli_query($con,"select * from test_topic where test_chapter_id = '$id'");
                                        if(mysqli_num_rows($query) > 0){
                                            while($row=mysqli_fetch_assoc($query)){
                                                //echo $row[0];
                                                echo'<div class="col-md-6 col-sm-6">
                                                        <h4 style="font-family: Gill Sans, Gill Sans MT, Calibri, Trebuchet MS, sans-serif">'.$row['topic_name'].'</h4>
                                                        <div class="mu-latest-course-single">
                                                            <figure class="mu-latest-course-img embed-responsive embed-responsive-4by3" >';
                                                            if(preg_match('/youtube/',$row['topic_embed'])){
                                                                $youtube_link=str_replace("https://www.youtube.com/watch?v=" , "https://www.youtube.com/embed/", $row['topic_embed']);
                                                                echo' <iframe class="embed-responsive-item" width="407" height="310" src="'.$youtube_link.'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
                                                                //print_r($youtube_link);
                                                            }
                                                            elseif(preg_match('/youtu.be/',$row['topic_embed'])){
                                                                $youtube_embed_link=str_replace("https://youtu.be/" , "https://www.youtube.com/embed/", $row['topic_embed']);
                                                                echo' <iframe class="embed-responsive-item" width="407" height="310" src="'.$youtube_embed_link.'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
                                                            }
                                                            elseif(preg_match('/dailymotion/',$row['topic_embed'])){
                                                                $dailymotion_link=str_replace("https://www.dailymotion.com/video","https://www.dailymotion.com/embed/video/" , $row['topic_embed']);
                                                                  echo'  <iframe class="embed-responsive-item" width="480" height="270" src="'.$dailymotion_link.'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen ></iframe>';    
                                                            }
                                                            elseif(preg_match('/dai.ly/',$row['topic_embed'])){
                                                                $dailymotion_embed_link=str_replace("https://dai.ly/","https://www.dailymotion.com/embed/video/" , $row['topic_embed']);
                                                                echo'  <iframe class="embed-responsive-item" width="480" height="270" src="'.$dailymotion_embed_link.'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen ></iframe>';    
                                                            }
                                                            else{
                                                                echo 'error ';
                                                            } 
                                                           
                                                          echo'  
                                                                <figcaption class="mu-latest-course-imgcaption">
                                                                    <a href="paper.php?id='. $row['id'].'">Take A Question</a>
                                                                </figcaption>
                                                            </figure>
                                                            <div class="mu-latest-course-single-content">                                                   
                                                                <p>'. $row['topic_article'].'</p>
                                                                <div class="mu-latest-course-single-contbottom text-center">
                                                                    <a class=" btn btn-primary" href="preparepaper.php?id='. $row['id'].'">Take A Question</a>                                            
                                                                </div>      
                                                            </div>
                                                        </div>
                                                    </div>';
    
                                            } 
                                        }
                                        else{
                                            echo'No Chapter Found';
                                        }
                                        
                                        ?>
                                    </div>
                                </div>
                                <!-- end course content container -->
                                <!-- start course pagination -->
                              
                                <!-- end course pagination -->
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    
    <!-- Start footer -->
    <?php 
    @include('includeFile/footer.php')
    ?>