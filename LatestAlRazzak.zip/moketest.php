<?php
include_once 'connect.php';

if (!isset($_SESSION['access_token'])) {
    header("location:sociallogin.php");
}
?>
<?php
    
    @include('includeFile/header.php');
    ch_title("Moke Test");
?>

<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
</a>

<?php
    @include('includeFile/admin_navbar.php')
?>
<section id="mu-course-content" style="background-color: white">
        <div class="container">
            <div class="row">
                <?php
                   echo 
                    '<div class="col-md-12">
                        
                        <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Moke Test</h1>
                                <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                    <hr>
                                </div>             
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <ol class="cs">';
                                $query=mysqli_query($con,"select * from moke_title ");
                                if(mysqli_num_rows($query) > 0){
                                    while($row=mysqli_fetch_assoc($query)){
                                        echo'   <li><a href="mokepaper.php?id='.$row['id'].'">'.$row['job_title'].'</a></li>';
                                        }    
                                }
                                else{
                                    echo'  <h1>No Record</li>';
                                }
                                
                    echo' </ol>
                        
                        </div>';
                ?>       
            </div>
        </div>
</section>




<?php 
    @include('includeFile/footer.php')
?>