<?php

if(isset($_POST['submit'])){
    include('connect.php');

    if( empty($_POST['subject']) || empty($_POST['chapter']) || empty($_POST['question']) || empty($_POST['correct']) || empty($_POST['option1']) || empty($_POST['option2']) || empty($_POST['option3']) || empty($_POST['option4'])){
        header('location:addquestion.php?response=error&class=danger&message=All fields are mandatory.');
    }
    else{
        $subject=$_POST['subject'];
        $chapter=$_POST['chapter'];
        $question=$_POST['question'];
        $correct=$_POST[$_POST['correct']];
        $option1=$_POST['option1'];
        $option2=$_POST['option2'];
        $option3=$_POST['option3'];
        $option4=$_POST['option4'];

        $query=mysqli_query(
            $con,"insert into question (subject_id,chapter_id,question,correct,option1,option2,option3,option4)
                    values('$subject','$chapter','$question','$correct','$option1','$option2','$option3','$option4')
                ");
            if($query){
                header('location:addquestion.php?response=success&class=success&message=Record has been added');
            }   
        }
    }
?>