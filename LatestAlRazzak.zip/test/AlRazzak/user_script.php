<?php
if (isset($_POST['submit'])) {
 	include('connect.php');
 	if( empty($_POST['username']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['assignsubject']) ){
        header('location:adduser.php?response=error&class=danger&message=All fields are mandatory.');
    }
    else{
    	$username=$_POST['username'];
    	$email=$_POST['email'];
    	$password=$_POST['password'];
    	$assignsubject=$_POST['assignsubject'];
        $assign=implode(',', $assignsubject);
    	$query=mysqli_query($con,"insert into user(username,email,password,permission,role) values('$username','$email','$password','$assign','editor')");
    	if ($query) {
    		header('location:adduser.php?response=success&class=success&message=Record has been added');
    	}
    	else{
    		header('location:adduser.php?response=error&class=danger&message=error');	
    	}
    }
 } 
?>