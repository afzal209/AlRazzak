<?php
include_once 'connect.php';

@include('header.php');

ch_title("Chapter");
?>

    <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- END SCROLL TOP BUTTON -->

    <!-- Start header  -->

    <!-- End header  -->
    <!-- Start menu -->
    <?php
    @include('navbar_subject.php')
     ?>
    <!-- End menu -->
    <!-- Start search box -->
    
    <!-- End search box -->
    <!-- Page breadcrumb -->
    <!-- <section id="mu-page-breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mu-page-breadcrumb-area">
                        <h2>Course</h2>
                        <ol class="breadcrumb">
                            <li><a href="#">Home</a></li>
                            <li class="active">Course</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- End breadcrumb -->
    <section id="mu-course-content" style="background-color: whitesmoke">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mu-course-content-area">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- start course content container -->
                                <div class="mu-course-container ">
                                    <div class="row">
                                    <?php
                                        $id=$_GET['id'];
                                        $query=mysqli_query($con,"select * from chapter where id = '$id'");
                                        while($row=mysqli_fetch_array($query)){
                                            //echo $row[0];
                                       ?>
                                        <div class="col-md-6 col-sm-6">
                                            <h4 style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"><?php echo $row['chapter_name'];?></h4>
                                            <div class="mu-latest-course-single">
                                                <figure class="mu-latest-course-img embed-responsive embed-responsive-4by3" >
                                                <iframe class="embed-responsive-item" width="407" height="310" src="https://www.youtube.com/embed/<?php echo $row['chapter_image'];?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`
                                                    <figcaption class="mu-latest-course-imgcaption">
                                                        <a href="paper.php?id=<?php echo $row['id']?>">Take A Question</a>
                                                    </figcaption>
                                                </figure>
                                                <div class="mu-latest-course-single-content">                                                   
                                                    <p><?php echo $row['chapter_article'];?></p>
                                                    <div class="mu-latest-course-single-contbottom text-center">
                                                        <a class=" btn btn-primary" href="paper.php?id=<?php echo $row['id'] ?>">Take A Question</a>                                            
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        } 
                                        ?>
                                    </div>
                                </div>
                                <!-- end course content container -->
                                <!-- start course pagination -->
                              
                                <!-- end course pagination -->
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Start footer -->
    <?php 
    @include('footer.php')
    ?>