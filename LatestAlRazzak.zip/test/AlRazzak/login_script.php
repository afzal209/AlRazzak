<?php
	
include('connect.php');

error_reporting(0);

if(isset($_POST['submit'])){
	//echo 'test';

	$email=$_POST['email'];
	$password=$_POST['password'];
	$select=mysqli_query($con,"select * from user where email='$email' and password='$password'");
	$nemail = false;
	$npass = false;
	
	while($row=mysqli_fetch_assoc($select)){
		$_SESSION['user']['email'] = $nemail = $row['email'];
		$_SESSION['user']['password'] = $npass = $row['password'];
		//$_SESSION = $row;
		foreach($row as $key=>$val){
			$_SESSION['user'][$key] = $val;
		}
		//echo '<pre>'.print_r(@$_SESSION,true).'</pre>';
	}
	
	if(isset($_SESSION['user']['email'])){
        header('location: dashboard.php');
	}
	else{
		header('location: login.php?response=error&class=danger&message=Invalid Credentials!');
	}
			
}

?>
