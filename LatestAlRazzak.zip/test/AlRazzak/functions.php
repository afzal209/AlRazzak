<?php
    include_once 'connect.php';
    function getPaperQuestions($GETVar = array()){
        
        $page = (isset($GETVar['page'])) ? $GETVar['page'] : 1;
                
        $questionPerPage = 1;
        $startingQuestion = ($page * $questionPerPage) - $questionPerPage;
        $id = $GETVar['id'];

        $result = array();
        $query=mysqli_query($con,"SELECT chapter.chapter_name,question.* 
                    FROM chapter
                    RIGHT JOIN question ON chapter.id = question.chapter_id 
                    where chapter_id = '$id'
                    ORDER BY question.id ASC
                    LIMIT $startingQuestion, $questionPerPage
                ");
        while($row=mysqli_fetch_array($query)){
            array_push($result, $row);
        }
        return $result;
    }
?>