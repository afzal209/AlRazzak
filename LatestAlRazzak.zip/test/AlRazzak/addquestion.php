<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>
<?php
    $session_permission = $_SESSION['user']['permission'];
    //echo $session_var;
    $session_permission = explode(',' ,$session_permission);
    //echo '<pre>'.print_r($session_permission,true).'</pre>';
    $session_permission = "'".implode("','",$session_permission)."'";
    //echo $session_permission;
    $where = "";
    if($_SESSION['user']['role'] == 'editor'){
        $where = "where id IN ($session_permission)";
    }
    $query=mysqli_query($con,"select * from subject $where");
    $resultSubjects = array();
    while($row=mysqli_fetch_assoc($query)){
        $resultSubjects[] = $row;
    }
    //echo '<pre>'.print_r($resultSubjects,true).'</pre>';
?>
<?php
include_once 'header.php';
ch_title("Add Paper");
include_once 'admin_navbar.php';
?>

<section id="mu-contact" style="background-color: whitesmoke">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Add Question</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="question_script.php">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                    echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }

                                        ?>
                                        <p class="">
                                            <label for="author">Choose Subject <span class="required">*</span></label>
                                            <select name="subject" id="subject" class="form-control">
                                                <option value=""></option>
                                                <?php 
                                                foreach($resultSubjects as $key=>$subject){
                                                    echo '<option value="'.$subject['id'].'" > '.$subject['subject_name'].' </option>';
                                                }
                                            ?>
                                            </select>
                                        </p>
                                        <p class="">
                                            <label for="author">Choose Chapter <span class="required">*</span></label>
                                            <select name="chapter" id="chapter" class="form-control">
                                                <option value=""></option>
                                            </select>
                                        </p>
                                        <p class="comment-form-comment">
                                            <label for="question">Question</label>
                                            <textarea  aria-required="true" rows="8" cols="45" name="question"></textarea>
                                        </p>
                                        
                                        <p class="comment-form-author">
                                            <label for="option1">Option 1 <span class="required">*</span></label>
                                            <input type="text"  size="30" value="" name="option1" id="option1">
                                        </p>           
                                        <p class="comment-form-author">
                                            <label for="option2">Option 2 <span class="required">*</span></label>
                                            <input type="text"  size="30" value="" name="option2" id="option2">
                                        </p>           
                                        <p class="comment-form-author">
                                            <label for="option3">Option 3 <span class="required">*</span></label>
                                            <input type="text"  size="30" value="" name="option3" id="option3">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="option4">Option 4 <span class="required">*</span></label>
                                            <input type="text"  size="30" value="" name="option4" id="option4">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="correct">Correct Answer <span class="required">*</span></label>
                                            <select name="correct" id="correct" class="form-control">
                                                <option value=""></option>
                                                <option value="option1">Option 1</option>
                                                <option value="option2">Option 2</option>
                                                <option value="option3">Option 3</option>
                                                <option value="option4">option 4</option>
                                            </select>
                                        </p>          
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(e){
            $('#subject').on('change', function(e){
                //console.log(e);
                var req_id=e.target.value;
                 //console.log(req_id);
                $.get('server.php?id='+req_id, function(data){
                    //console.log(data);
                    var result = JSON.parse(data);
                    //console.log(result);
                    $('#chapter').empty();
                    for(var i=0; i<result.length; i++){
                        //console.log(result[i].id);
                        $('#chapter').append('<option value="'+ result[i].id+'">'+result[i].chapter_name+'</option>');
                    }
                });
            });
        });
    </script>   
<?php
include('footer.php')
?>