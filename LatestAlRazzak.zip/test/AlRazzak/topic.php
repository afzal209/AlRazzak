<?php
    include_once 'connect.php';
    @include('header.php');
    ch_title("Topic");
?>

<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
</a>

 <!-- Start menu -->
<?php
    @include('navbar_subject.php')
?>

<section id="mu-course-content" style="background-color: white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   
                        <?php
                            @$id=$_GET['id'];
                            $query=mysqli_query($con,"select subject_name from subject where id='$id'");
                            $row=mysqli_fetch_assoc($query);
                            echo '<h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">'.$row['subject_name'].'</h1>
                                  <h1 style="font-family: Arial, Helvetica, sans-serif;">Topic</h1>';
                        ?>
                                            
                </div>
                        <div class="col-md-12 col-sm-12">
                            <ol class="cs">
                                <?php
                                    @$id=$_GET['id'];
                                    $a=1;
                                    $query=mysqli_query($con,"select * from chapter where subject_id='$id'");
                                    while($row=mysqli_fetch_assoc($query)){
                                        echo '<li><a href= "chapter.php?id='.$row['id'].'" >'.$row['chapter_name'].'</a></li>';
                                    } 
                                ?>
                            </ol>
                        </div>
                </div>
            </div>
        </div>
    </section>




<?php 
    @include('footer.php')
?>