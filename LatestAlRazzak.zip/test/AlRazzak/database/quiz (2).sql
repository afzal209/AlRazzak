-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 12, 2019 at 09:30 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `chapter`
--

CREATE TABLE `chapter` (
  `id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `chapter_name` varchar(20) NOT NULL,
  `chapter_image` varchar(200) NOT NULL,
  `chapter_article` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapter`
--

INSERT INTO `chapter` (`id`, `subject_id`, `chapter_name`, `chapter_image`, `chapter_article`) VALUES
(1, 1, 'Chapter 1', 'image/Capture.PNG', 'Chapter 1 Article'),
(2, 2, 'Chapter 2', 'image/Capturepic.PNG', 'Chapter 2 Article'),
(3, 3, 'Chapter 3', 'image/error.PNG', 'Chapter 3 Article');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, '.afzal.', '.afzal_209@hotmail.c', '.test.', '.testing message.'),
(2, '.test.', '.test@gmail.com.', '.test me .', '.testing email.'),
(3, '.test.', '.test@gmail.com.', '.test me .', '.testing email.'),
(4, '.test.', '.test029@gmail.com.', '.testq.', '.test.'),
(5, '.test.', '.test029@gmail.com.', '.testq.', '.test.'),
(6, '.test.', '.test029@gmail.com.', '.testq.', '.test.'),
(7, '.test.', '.test029@gmail.com.', '.testq.', '.test.'),
(8, '.test.', '.test029@gmail.com.', '.testq.', '.test.'),
(9, '.abc.', '.abc@gmail.com.', '.abc123.', '.abc123.'),
(10, 'effert', 'effert@gmail.com', 'effert', 'effert'),
(11, 'session ', 'session@gmail.com', 'session123', 'session123\r\n'),
(12, 'session ', 'session@gmail.com', 'session123', 'session123\r\n'),
(13, 'session ', 'session@gmail.com', 'session123', 'session123\r\n'),
(14, '..', '..', '..', '..'),
(15, '..', '..', '..', '..'),
(16, '..', '..', '..', '..'),
(17, '..', '..', '..', '..'),
(18, '..', '..', '..', '..'),
(19, '', '', '', ''),
(20, '', '', '', ''),
(21, 'ert', 'ert@gmail.com', 'ert', 'ert123'),
(22, 'session ', 'ali@gmail.com', 'test', 'sdadas'),
(23, '', '', '', ''),
(24, '', '', '', ''),
(25, '', '', '', ''),
(26, '', '', '', ''),
(27, '', '', '', ''),
(28, '', '', '', ''),
(29, '', '', '', ''),
(30, 'session ', 'admin_mckj@gmail.com', 'testq', 'asdasd'),
(31, 'sadasd', 'ariba.khatri.3@gmail', 'test me ', 'dsadasd'),
(32, 'session ', 'afzal_209@hotmail.co', 'Project', 'adasddasd'),
(33, 'adasd', 'ali@gmail.com', 'asdas', 'adasdas'),
(34, '', '', '', ''),
(35, 'dasdasd', 'afzal_209@hotmail.co', 'asdasd', 'asdasd'),
(36, '', '', '', ''),
(37, 'asdasd', 'asdasd@gmail.com', 'asdasd', 'sadasdas'),
(38, 'asdasd', 'afzal_209@hotmail.co', 'adsad', 'asdasd'),
(39, '', '', '', ''),
(40, 'adasd', 'asad@gmail.com', 'adasd', 'asdasd'),
(41, '', '', '', ''),
(42, '', '', '', ''),
(43, '', '', '', ''),
(44, '', '', '', ''),
(45, '', '', '', ''),
(46, '', '', '', ''),
(47, '', '', '', ''),
(48, '', '', '', ''),
(49, '', '', '', ''),
(50, '', '', '', ''),
(51, 'afzal', 'afzal_209@hotmail.co', 'Project', 'aadasd'),
(52, '', '', '', ''),
(53, 'session ', 'admin@gmail.com', 'asdasd', 'asdasd'),
(54, '', '', '', ''),
(55, '', '', '', ''),
(56, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `chapter_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `correct` varchar(30) NOT NULL,
  `option1` varchar(30) NOT NULL,
  `option2` varchar(30) NOT NULL,
  `option3` varchar(30) NOT NULL,
  `option4` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `subject_id`, `chapter_id`, `question`, `correct`, `option1`, `option2`, `option3`, `option4`) VALUES
(1, 1, 1, 'question 1', 'o1', 'o1', 'o2', 'o3', 'o4'),
(2, 3, 3, 'Help', 'asg', 'asg', 'agsa', 'sgsda', 'sag'),
(3, 1, 1, 'Quesag', 'c', 'a', 'b', 'c', 'd'),
(4, 3, 3, 'Help', 'asf', 'asgasas', 'asf', 'sgsdaas', 'sagasfg'),
(5, 1, 1, 'question 3', 'o3', 'o1', 'o2', 'o3', 'o4');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `subject_image` varchar(200) NOT NULL,
  `subject_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `subject_image`, `subject_name`) VALUES
(1, 'image/Capture.PNG', 'Subject 1'),
(2, 'image/Capturepic.PNG', 'Subject 2'),
(3, 'image/error.PNG', 'subject 3');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`) VALUES
(1, 'afzal_ahmed', 'admin@gmail.com', 'admin123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chapter`
--
ALTER TABLE `chapter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chapter_id` (`chapter_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chapter`
--
ALTER TABLE `chapter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chapter`
--
ALTER TABLE `chapter`
  ADD CONSTRAINT `chapter_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`chapter_id`) REFERENCES `chapter` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
