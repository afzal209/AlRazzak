<?php

session_start();
$con=mysqli_connect('localhost','root','','quiz');


// if($con){
//     echo "<script>alert('connect')</script>";
// }
// else{
//     echo "<script>alert('not connect')</script>";
// }


?>