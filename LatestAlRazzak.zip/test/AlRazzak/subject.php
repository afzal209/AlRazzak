<?php
include_once 'connect.php';
@include('header.php');
ch_title("Subject");
?>

    <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- END SCROLL TOP BUTTON -->

    <!-- Start header  -->

    <!-- End header  -->
    <!-- Start menu -->
    <?php
    @include('navbar_subject.php')
     ?>
    <!-- End menu -->
    <!-- Start search box -->
    
    <!-- End search box -->
    <!-- Page breadcrumb -->
    <!-- <section id="mu-page-breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mu-page-breadcrumb-area">
                        <h2>Course</h2>
                        <ol class="breadcrumb">
                            <li><a href="#">Home</a></li>
                            <li class="active">Course</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- End breadcrumb -->
    <section id="mu-course-content" style="background-color: whitesmoke">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mu-course-content-area">
                        <div class="row">
                            <div class="col-md-9">
                                <!-- start course content container -->
                                <div class="mu-course-container">
                                    <div class="row">
                                        <?php
                                        $query=mysqli_query($con,'select * from subject');
                                        while($row=mysqli_fetch_array($query)){ 
                                        ?>
                                        <div class="col-md-6 col-sm-6">
                                            <div class="mu-latest-course-single">
                                                <figure class="mu-latest-course-img">

                                                    <a href="#"><img src="<?php echo $row[1] ?>" alt="img" width="350" height="300" ></a>
                                                    
                                                </figure>
                                                <div class="mu-latest-course-single-content">
                                                    <h4 id="txt"><a href="chapter.php?id=<?php echo $row['id'];?>"><?php echo $row['subject_name']?></a></h4>
                                                   
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                                <!-- end course content container -->
                                <!-- start course pagination -->
                                <div class="mu-pagination">
                                    <nav>
                                        <ul class="pagination">
                                            <li>
                                                <a href="#" aria-label="Previous">
                                                    <span class="fa fa-angle-left"></span> Prev
                                                </a>
                                            </li>
                                            <li class="active"><a href="#">1</a></li>
                                            <li><a href="#">2</a></li>
                                            <li><a href="#">3</a></li>
                                            <li><a href="#">4</a></li>
                                            <li><a href="#">5</a></li>
                                            <li>
                                                <a href="#" aria-label="Next">
                         Next <span class="fa fa-angle-right"></span>
                        </a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                                <!-- end course pagination -->
                            </div>
                            <div class="col-md-3">
                                <!-- start sidebar -->
                                <aside class="mu-sidebar">
                                    <!-- start single sidebar -->
                                    <div class="mu-single-sidebar">
                                        <h3>Categories</h3>
                                        <ul class="mu-sidebar-catg">
                                             <?php
                                                $query=mysqli_query($con,'select         * from subject');
                                                while($row=mysqli_fetch_array           ($query)){ 
                                                ?>
                                            <li><a href="chapter.php?id=<?php echo $row['id'];?>"><?php echo $row['subject_name']?></a></li>
                                            <?php
                                                }
                                            ?>
                                        </ul>
                                    </div>
                                    <!-- end single sidebar -->
                                    <!-- start single sidebar -->
                                   
                                    <!-- end single sidebar -->
                                    <!-- start single sidebar -->
                                    
                                    <!-- end single sidebar -->
                                    <!-- start single sidebar -->
                                 
                                    <!-- end single sidebar -->
                                </aside>
                                <!-- / end sidebar -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Start footer -->
    <?php 
    @include('footer.php')
    ?>