<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
if ($_SESSION['user']['role'] == 'admin') {    
?>



<?php
include_once 'header.php';
ch_title("Add User");
include_once 'admin_navbar.php';
?>

<section id="mu-contact" style="background-color: whitesmoke">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Add Users</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="user_script.php">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                    echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }

                                        ?>
                                         <p class="comment-form-author">
                                            <label for="username">Username <span class="required">*</span></label>
                                            <input type="text"   value="" name="username">
                                        
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="email">Email <span class="required">*</span></label>
                                            <input type="email" value="" name="email">
                                        
                                        </p>
                                        <p class="comment-form-email">
                                            <label for="password"> Password <span class="required">*</span></label>
                                            <input type="password"   value="" name="password" style="width: 100%; height: 35px;">
                                       </p>
                                              <p class="comment-form-email">
                                            <label for="assignsubject">Assign Subject <span class="required">*</span></label>
                                            <select class="form-control selectpicker" multiple data-live-search="true" name="assignsubject[]">
                                            	<?php
                                            	$query=mysqli_query($con,"select * from subject");
                                            	while ($row=mysqli_fetch_assoc($query)) { 
                                            	?>
                                            	<option value="<?php echo $row['id'];?>"><?php echo $row['subject_name'];?></option>
                                            	<?php 
                                            		}
                                            	?>
                                            </select>
                                       </p>   
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>

<?php
include('footer.php')
?>

<?php
    }
    else {
         header('location:addchapter.php');
     } 
?>