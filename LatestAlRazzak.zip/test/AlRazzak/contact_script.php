<?php
$success = '';
if(isset($_POST['submit'])){
    
    $name=$_POST['author'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['comment'];

    $mailTo = "afzal_209@hotmail.com";
    $header = "From: ".$email;
    $txt = "You have receive any email from ".$name.".\n\n".$message;

    if(mail($mailTo,$subject,$txt,$header)){
      $success = "We will contact you soon";
    }
    

};
?>