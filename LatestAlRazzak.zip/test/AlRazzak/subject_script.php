<?php 

if(isset($_POST['submit'])){
    include('connect.php');

    if( empty($_POST['text'])){
        header('location:addsubject.php?response=error&class=danger&message=Please fill the Record');
    }
    else
    {
        $image=$_FILES['image']['tmp_name'];
        $image_name=$_FILES['image']['name'];
        $location="image/";
            $name= $_POST['text'];
         if(move_uploaded_file($image, $location.$image_name))
         {
            $query=mysqli_query($con,"insert into subject(subject_image,subject_name) values('$location$image_name','$name')");
            if($query){
                //echo "<p class='alert alert-success'>inserted success</p>";
                header('location:addsubject.php?response=success&class=success&message=Record inserted Successfully');
            }
            else{
                //echo "<p class='alert alert-success'>inserted success</p>";
                header('location:addsubject.php?response=error&class=danger&message=error');
            }
         }
    }

}
?>