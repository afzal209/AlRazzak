<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>
<?php
    $session_permission = $_SESSION['user']['permission'];
    //echo $session_var;
    $session_permission = explode(',' ,$session_permission);
    //echo '<pre>'.print_r($session_permission,true).'</pre>';
    $session_permission = "'".implode("','",$session_permission)."'";
    //echo $session_permission;
    $where = "";
    if($_SESSION['user']['role'] == 'editor'){
        $where = "where id IN ($session_permission)";
    }
    $query=mysqli_query($con,"select * from subject $where");
    $resultSubjects = array();
    while($row=mysqli_fetch_assoc($query)){
        $resultSubjects[] = $row;
    }
    //echo '<pre>'.print_r($resultSubjects,true).'</pre>';
?>
<?php
include_once 'header.php';
ch_title("Add Chapter");
include_once 'admin_navbar.php';
?>

<section id="mu-contact" style="background-color: whitesmoke">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Add Chapter</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="chapter_script.php" enctype="multipart/form-data">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                             echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }

                                        ?>
                                        <p class="">
                                            <label for="author">Choose Subject <span class="required">*</span></label>
                                           
                                            <select name="subject" id="" class="form-control">
                                                <option></option>
                                            <?php 
                                                foreach($resultSubjects as $key=>$subject){
                                                    echo '<option value="'.$subject['id'].'" > '.$subject['subject_name'].' </option>';
                                                }
                                            ?>
                                                
                                            </select>
                                            
                                        </p>
                                         <p class="comment-form-author">
                                            <label for="name">Chapter Name <span class="required">*</span></label>
                                            <input type="text"  size="30" value="" name="name">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="video">Video Link <span class="required">*</span></label>
                                            <input type="text"   value="" name="video">
                                        </p>
                                        <p class="comment-form-comment">
                                            <label for="article">Article</label>
                                            <textarea  aria-required="true" rows="8" cols="45" name="article"></textarea>
                                        </p>              
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>


<?php
include('footer.php')
?>
