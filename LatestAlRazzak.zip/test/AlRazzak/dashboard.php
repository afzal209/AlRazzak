<?php 

include_once 'connect.php';   

if(!isset($_SESSION['user']['email']))

{

    header('location:login.php');

}



?>











<?php

include_once 'header.php';

ch_title("Dashboard");

include('admin_navbar.php'); 



?>



<section id="mu-course-content">

        <div class="container">

            <div class="row">

                <div class="col-md-12">

                    <div class="col-md-6 col-sm-6" >

                        <button class="btn btn-default btn-lg btn_size">Total Subject1</button>

                    </div>

                   

                    <div class="col-md-6 col-sm-6" >

                        <button class="btn btn-default btn-lg btn_size">Total Subject2</button>

                    </div>

                    

                    <div class="col-md-6 col-sm-6" >

                        <button class="btn btn-default btn-lg btn_size">Total Subject3</button>

                    </div>

                    

                    <div class=" col-md-6 col-sm-6" >

                        <button class="btn btn-default btn-lg btn_size" >Total Subject4</button>

                    </div>

                </div>

            </div>

        </div>

</section>



















<?php

include('footer.php')

?>



<?php



?>