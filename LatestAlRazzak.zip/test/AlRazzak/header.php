<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Varsity | Home</title>
    <?php require "title_script.php"; ?>
    <!-- Favicon -->
    <?php
     @include('css.php')
     ?>
      <style>
      #link{
        color:black;
      }
     
      .change{
        margin-left:19%;
      }
      .cs{
        font-size: 30px;
        font-family: Arial, Helvetica, sans-serif;
        margin-left: 5%;  
      }
      #txt{
        text-align: center;
      }
      #txt1{
          margin-left: 15%; 
      }
      .btn_size{
        padding: 20px 30px;
        border-radius: 10px;
        margin-top: 5%;
        font-size: 15px;
      }
      #m-footer {
        display: inline;
        float: left;
        width: 100%;
        
       
      }
      #m-footer .m-footer-bottom {
          background-color: #222;
          display: inline;  
          float: left;
          padding: 25px 0;
          width: 100%;
      }
      #m-footer .m-footer-bottom .m-footer-bottom-area {
          display: inline;
          float: left;
          text-align: center;
          width: 100%;
      }
      #m-footer .m-footer-bottom .m-footer-bottom-area p {
          color: #fff;
          margin-bottom: 0;
          letter-spacing: 0.3px;
      }

      #m-footer .m-footer-bottom .m-footer-bottom-area p a {
          color: #fff;
      }
       #iframe-container{
        position: relative;
        width: 100%;
        padding-bottom: 40%;
        height: 0;
      }
      #iframe-container iframe{
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
      }
      th {
        font-size: 20px;
      }
      td{
        text-align: center;
      }
      </style>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>