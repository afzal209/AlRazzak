<?php 

session_start();

if (isset($_SESSION['access_token'])) {

    session_destroy();

    header("location: ../sociallogin.php");

}

// session_unset();
   
// $_SESSION['userData']['first_name'] = NULL;
// $_SESSION['userData']['last_name'] = NULL;
// $_SESSION['userData']['email'] =  NULL;
// $_SESSION['userData']['picture']['url'] = NULL;
// header("location: ../sociallogin.php");   





?>