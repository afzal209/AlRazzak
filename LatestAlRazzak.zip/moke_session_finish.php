<?php 
$id= $_GET['id'];
header('location:moketest.php?id='.$id);

exist();
?>