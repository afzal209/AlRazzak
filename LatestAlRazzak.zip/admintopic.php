<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>
<?php
    include_once 'connect.php';
    @include('includeFile/header.php');
    ch_title("Admin Topic");
?>

<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
</a>

 <!-- Start menu -->
<?php
    @include('includeFile/admin_navbar.php')
?>

<section id="mu-course-content" style="background-color: white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   
                        <?php
                            @$id=$_GET['id'];
                            //$query=mysqli_query($con,"select subject_name from subject where id='$id'");
                            $query=mysqli_query($con,"select academic.* , subject.*,chapter.* from academic inner join subject on academic.id = subject.academy_id inner join chapter on subject.id = chapter.subject_id where chapter.id='$id'");
                            $row=mysqli_fetch_assoc($query);
                            echo '
                                    <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Moke Test</h1>
                                    <h1 style="font-family: Arial, Helvetica, sans-serif;"><a href="adminacademic.php">Academic></a>'.$row['academic_name'].'><a href="adminsubject.php?id='.$row['academy_id'].'">Subject</a>>'.$row['subject_name'].'><a href="adminchapter.php?id='.$row['subject_id'].'"Chapter>'.$row['chapter_name'].'</h1>
                                    <h1 style="font-family: Arial, Helvetica, sans-serif;">Topic</h1>';
                        ?>
                                            
                </div>
                        <div class="col-md-6 col-sm-6">
                            <ol class="cs">
                                <?php
                                    echo '<h3 class="text-center">Topic</h3>';
                                    @$id=$_GET['id'];
                                    $a=1;
                                    $query=mysqli_query($con,"select * from topic where chapter_id='$id'");
                                    while($row=mysqli_fetch_assoc($query)){
                                        echo '<li><a href= "adminquestion.php?id='.$row['id'].'" >'.$row['topic_name'].'</a></li>';
                                    } 
                                ?>
                            </ol>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <ul class="cs">
                                <?php
                                echo '<h3 class="text-center">Academic</h3>'; 
                                $query=mysqli_query($con,"select * from academic ");
                                while($row=mysqli_fetch_assoc($query)){
                                    echo '<li><a href= "adminsubject.php?id='.$row['id'].'" >'.$row['academic_name'].'</a></li>';
                                }
                                ?>
                            </ul>
                                        
                        </div>
                </div>
            </div>
        </div>
    </section>




<?php 
    @include('includeFile/footer.php')
?>