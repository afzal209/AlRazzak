<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>
<?php
    
    
    @include('includeFile/header.php');
    ch_title("Admin Chapter");
?>

<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
</a>

 <!-- Start menu -->
<?php
    @include('includeFile/admin_navbar.php')
?>

<section id="mu-course-content" style="background-color: white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   
                        <!-- <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Moke Test</h1>
                                  <h1 style="font-family: Arial, Helvetica, sans-serif;">Subjects</h1> -->

                        <?php
                            @$id=$_GET['id'];
                            $query=mysqli_query($con,"select academic.* , subject.* from academic inner join subject on academic.id = subject.academy_id where subject.id='$id'");
                            $row=mysqli_fetch_assoc($query);
                            echo '
                                    <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Moke Test</h1>
                                    <h1 style="font-family: Arial, Helvetica, sans-serif;"><a href="adminacademic.php">Academic></a>'.$row['academic_name'].'><a href="adminsubject.php?id='.$row['academy_id'].'">Subject</a>>'.$row['subject_name'].'>Chapter</h1>
                                    <h1 style="font-family: Arial, Helvetica, sans-serif;">Chapter</h1>';
                        ?>
                       
                                            
                </div>
                        <div class="col-md-12 col-sm-12">
                            <ol class="cs">
                                <?php
                                    $id = $_GET['id'];
                                    $query=mysqli_query($con,"select * from chapter where subject_id = '$id' ");
                                    while($row=mysqli_fetch_assoc($query)){
                                        echo '<li><a href= "admintopic.php?id='.$row['id'].'" >'.$row['chapter_name'].'</a></li>';
                                    } 
                                ?>
                            </ol>
                        </div>
                </div>
            </div>
        </div>
    </section>




<?php 
    @include('includeFile/footer.php')
?>