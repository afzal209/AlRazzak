<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>

<?php
include_once 'includeFile/header.php';
ch_title("View Chapter");
include_once 'includeFile/admin_navbar.php';
?>





<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>View Chapter</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div  class="col-md-12 col-sm-12 table-responsive" >
                            <?php
                            if(@$_GET['response'] != ''){

                                echo '  <div class="alert alert-'.@$_GET['class'].'">

                                         <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'

                                     </div>';

                                 }
                                echo'<table class="table table-bordered  table-striped" id="example">
                                    <thead>
                                        <th>Subject</th>
                                        <th>Chapter Name</th>
                                       
                                        <th>Action</th>
                                    </thead>';
                                    
                                        $query=mysqli_query($con,'select subject.subject_name,chapter.* from subject RIGHT JOIN chapter ON subject.id = chapter.subject_id where chapter.subject_id = subject.id');
                                        while($row=mysqli_fetch_assoc($query)){ 
                                         
                                        echo '<tr>
                                            <td>'. $row['subject_name'].'</td>
                                            <td>'. $row['chapter_name'].'</td>
                                           
                                            <td><a href="chapterupdate.php?id=' .$row['id'].'"><span class="glyphicon glyphicon-pencil"></span></a>/<a href="chapterdelete.php?id='. $row['id'].'"><span class="glyphicon glyphicon-trash"></span></a></td>        
                                        </tr>';
                                    
                                        } 
                                    
                               echo' </table>';
                            ?>    
                        </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
} );    
</script>
    
<?php
include('includeFile/footer.php')
?>

