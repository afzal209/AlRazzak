<?php
include_once 'connect.php';
@include('includeFile/header.php');

ch_title("Jobs Ad");
?>
<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
    </a>
    
    <?php
        @include_once 'includeFile/admin_navbar.php';
    
echo'<section id="mu-course-content" style="background-color: white; padding: 18px 0;">
        <div class="container jb_main">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Jobs Ads</h1>
                    <div class="row">';
                       
                        include_once 'includeFile/company_name.php'; 
                        
                    echo'<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-top: 5px;">';
                        
                        include 'connect.php';
                        $query =mysqli_query($con,"select * from job_ads order by issue_date desc");
                        while($row=mysqli_fetch_assoc($query)){
                        echo '<div class="jb_cis">
                                    <a href="jobdetail.php?id='.$row['id'].'"><h1 style="font-family: Arial, Helvetica, sans-serif;font-size:15px;"><b>'.$row['job_title'].'</b><h1></a>
                                    <h1 class="jb_h1"><a href="jobinfo.php?issue_date='.$row['issue_date'].'" style="font-size: 30% ;color:blue;">'.$row['issue_date'].'</a><a href="jobinfo.php?source='.$row['source'].'" style="font-size: 30%;color:blue;margin-left:1%" >'.$row['source'].'</a></h1>    
                            </div>'; 
                        }
                        
                          
                     echo'</div>
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-top: 5px;">
                                 <h1 style="font-family: Arial, Helvetica, sans-serif; font-size:20px;"><b>Job by City</b></h1>';
                            $query = mysqli_query($con,"select DISTINCT city from job_info");
                            while($row=mysqli_fetch_assoc($query)){
                            echo'<div class="col-md-6 col-sm-6 col-xs-6">
                                    <a href="jobinfo.php?city='.$row['city'].'">'.$row['city'].'</a>
                                </div>';
                            }
                     echo '</div>  
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-top: 5px;">
                                <h1 style="font-family: Arial, Helvetica, sans-serif;font-size:20px;"><b>Job by Provinces</b></h1>';
                                $query = mysqli_query($con,"select DISTINCT provinces from job_info");
                                while($row=mysqli_fetch_assoc($query)){
                           echo'<div class="col-md-6 col-sm-6 col-xs-6">
                                    <a href="jobinfo.php?provinces='.$row['provinces'].'">'.$row['provinces'].'</a>
                                </div>';
                                }
                       echo'</div>
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-top: 5px;">
                                <h1 style="font-family: Arial, Helvetica, sans-serif;font-size:20px;"><b>Job by Issue Date</b></h1>';
                                $query = mysqli_query($con,"select DISTINCT issue_date from job_info");
                                while($row=mysqli_fetch_assoc($query)){
                           echo'<div class="col-md-6 col-sm-6 col-xs-6">
                                    <a href="jobinfo.php?issue_date='.$row['issue_date'].'">'.$row['issue_date'].'</a>
                                </div>';
                                }
                    echo' </div> 
                    </div>
                </div>
            </div>
        </div>
    </section>';
    ?>
<?php    
    include('includeFile/footer.php');
?>
