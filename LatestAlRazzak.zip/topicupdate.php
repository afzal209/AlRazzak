<?php 

include 'phpGetId/topic_getId.php';

ob_start();

include_once 'connect.php';

if(!isset($_SESSION['user']['email']))

{

    header('location:login.php');

}



?>











<?php



include_once 'includeFile/header.php';

ch_title("Update Topic");

include_once 'includeFile/admin_navbar.php';

?>







<section id="mu-contact" style="background-color: white">

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <div class="mu-contact-area">

                    <!-- start title -->

                    <div class="mu-title">

                        <h2>Update Topic</h2>

                    </div>

                    <!-- end title -->

                    <!-- start contact content -->

                

                    <div class="mu-contact-content" >           

                        <div class="row">

                            <div class="col-md-6">

                                <div class="mu-contact-left" >

                                    <form class="contactform" method="post" action="" >

                                        

                                       

                                         <p class="comment-form-author">

                                            <label for="name">Topic Name <span class="required">*</span></label>

                                            <input type="text"  size="30" value="<?php echo $name;?>" name="name">

                                        </p>

                                        <p class="comment-form-author">

                                            <label for="video">Video Link <span class="required">*</span></label>

                                            <input type="text"   value="<?php echo $embed;?>" name="video">

                                        </p>

                                        <p class="comment-form-comment">

                                            <label for="article">Article</label>

                                            <textarea  aria-required="true" rows="8" cols="45" name="article" ><?php echo $article; ?></textarea>

                                        </p>              

                                        <p class="form-submit">

                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">

                                        </p> 

                                            

                                    </form>

                                </div>

                            </div>

                    </div>

                </div>

                <!-- end contact content -->

            </div>

        </div>

    </div>

    

</section>





<?php

include('includeFile/footer.php')

?>





<?php



include('phpScript/update_topic_script.php');



?>