<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>

<?php
include_once 'includeFile/header.php';
ch_title("View User");
include_once 'includeFile/admin_navbar.php';
?>





<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>View User</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div  class="col-md-12 col-sm-12 table-responsive" >
                            
                            <?php
                            if(@$_GET['response'] != ''){

                                echo '  <div class="alert alert-'.@$_GET['class'].'">

                                         <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'

                                     </div>';

                                 }
                                    echo'<table class="table table-bordered  table-striped" id="example">
                                    <thead>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Permission </th>
                                        <th>Permission Subject</th>
                                        <th>Role</th>
                                        <th>Action</th>
                                    </thead>';
                                    
                                    $query=mysqli_query($con,'select user.*,user_permission.*,subject.*,academic.*,group_concat( subject.subject_name ) as permission_con  from user left join user_permission on user.id = user_permission.user_id LEFT JOIN subject ON subject.id = user_permission.permission_sub LEFT JOIN academic ON academic.id = user_permission.permission where user.id != 1 Group By user.username');
                                        if(mysqli_num_rows($query) > 0){
                                            while($row=mysqli_fetch_assoc($query)){ 
                                                //echo '<pre>'.print_r($row,true).'</pre>';
                                                // $permission= explode(',' , $row['permission']);
                                                // $array_permission=array($permission);
                                                //$permission= "'".implode("','" ,$array_permission)."'";
                                                //$permission_e=implode("|" , $array_permission);
                                                // $permission_json= json_encode($array_permission);
                                                // $query_check=mysqli_query($con,"select subject.subject_name,user.* from subject RIGHT JOIN user ON subject.id= '$permission_json'");
                                                //echo '<pre>'.print_r($query_check,true).'</pre>';
                                                //print_r($permission_json);
                                                echo '<tr>
                                                    <td>'. $row['username'].'</td>
                                                    <td>'. $row['email'].'</td>
                                                    <td>'. $row['academic_name'].'</td>
                                                    <td> '.$row['permission_con'] .'</td>
                                                    <td> '.$row['role'].' </td>
                                                    <td><a href="userpermission.php?id=' .$row['user_id'].'"><span class="glyphicon glyphicon-pencil"></span></a>/<a href="userupdate.php?id='.$row['user_id'].'"><span class="glyphicon glyphicon-edit"></span></a>/<a href="userdelete.php?id='. $row['user_id'].'"><span class="glyphicon glyphicon-trash"></span></a></td>        
                                                </tr>';
                                            
                                                }  
                                        }
                                        else{
                                            echo '  <tr>
                                                        <td colspan="6">No User Inserted</td>
                                                    </tr>
                                            ';
                                        }
                                         
                                    
                                echo' </table>';
                            ?>    
                        </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
} );    
</script>
    
<?php
include('includeFile/footer.php')
?>

