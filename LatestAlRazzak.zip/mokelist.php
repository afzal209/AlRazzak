<?php 

include_once 'connect.php';
if (!isset($_SESSION['access_token'])) {
    header("location:sociallogin.php");
}
// require_once 'facebookLogin/vendor/autoload.php';
//     $fb = new Facebook\Facebook([  
//         'app_id' => '964802107201645',
//         'app_secret' => '65ae0f9a1368762ba34db77e4547da3a',
//         'default_graph_version' => 'v2.10'
//     ]);

    // $helper = $fb->getRedirectLoginHelper();
    
    // $logoutUrl = $helper->getLogoutUrl('{EAAT3Roro30ABAOePSMuvZCXUxBpJmknKQrnGScjboRsTD1OAr2pEW9tJi8iW7sTSwBHOGulNBuUnLsXF8AhKavyRaEJ3znPAa473SVmw8jdE4jwBwcZCA4bxqYA7BFFCnvosvxQzQ4jWa8iYJwDpFxdRPoZBMsClZCMfATKfv3ph1DkLpbZBzCupjlh9awvRltF3f70l01QZDZD}', 'http://www.thepakdev.com');
    // echo '<a href="' . $logoutUrl . '">Logout of Facebook!</a>';
?>
<?php
    
    @include('includeFile/header.php');
    ch_title("Moke List");
?>

<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
</a>

 <!-- Start menu -->
<?php
    @include('includeFile/admin_navbar.php')
?>

<section id="mu-course-content" style="background-color: white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">    
                    <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Moke List</h1>
                    <h1 style="font-family: Arial, Helvetica, sans-serif;">Topic</h1>                        
                </div>
                <div class="col-md-12 col-sm-12">
                    <ol class="cs">
                        <?php
                            $query=mysqli_query($con,"select * from moke_title");
                            if(mysqli_num_rows($query) > 0){
                                while($row=mysqli_fetch_assoc($query))
                                {
                                    echo '<li><a href= "moketest.php?id='.$row['id'].'" >'.$row['job_title'].'</a></li>';
                                } 
                            }
                            else {
                                echo '<li>No Moke Test Available</li>';
                                
                            }
                           
                        ?>
                    </ol>
                </div>
            </div>
        </div>
</section>




<?php 
    @include('includeFile/footer.php')
?>