<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
} 
?>

<?php
include_once 'includeFile/header.php';
ch_title("Add Test Suject");
include_once 'includeFile/admin_navbar.php';
?>

<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Add Test Subject</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="phpScript/test_subject_script.php" >
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                    echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }
                                        
                                        ?>
                                        
                                        <p class="comment-form-email">
                                            <label for="text">Subject Name <span class="required">*</span></label>
                                            <input type="text"   value="" name="text" style="width: 100%; height: 35px;">
                                        
                                        </p>
                                        <input type="hidden" name="insert_by" value="<?php echo @$_SESSION['user']['username']; ?>" >         
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>


<?php
include('includeFile/footer.php')
?>