
<?php
include_once 'header.php';
ch_title("Forget Password");
include_once 'admin_navbar.php';
?>

<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Forget Password</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="forgotpass_script.php">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                    echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }

                                        ?>
                                        <p class="comment-form-author">
                                            <label for="email">Email <span class="required">*</span></label>
                                            <input type="text"   value="" name="email">
                                        
                                        </p>
                                           
                                        <p class="form-submit">
                                            <input type="submit" value="Reset Password" class="mu-post-btn" name="submit"> 
                                        </p>   
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>


<?php
include('footer.php')
?>

