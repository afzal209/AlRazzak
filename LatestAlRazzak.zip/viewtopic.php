<?php 

include_once 'connect.php';

if(!isset($_SESSION['user']['email']))

{

    header('location:login.php');

}

    

?>



<?php

include_once 'includeFile/header.php';

ch_title("View Topic");

include_once 'includeFile/admin_navbar.php';

?>











<section id="mu-contact" style="background-color: white">

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <div class="mu-contact-area">

                    <!-- start title -->

                    <div class="mu-title">

                        <h2>View Topic</h2>

                    </div>

                    <!-- end title -->

                    <!-- start contact content -->

                

                    <div class="mu-contact-content" >           

                        <div class="row">

                            <div  class="col-md-12 col-sm-12 table-responsive" >

                            <?php

                                 

                                 if(@$_GET['response'] != ''){

                                echo '  <div class="alert alert-'.@$_GET['class'].'">

                                         <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'

                                     </div>';

                                 }

                                 

                               if($_SESSION['user']['role'] == 'admin'){  

                                echo'<table class="table table-bordered  table-striped">

                                    <tr>

                                        <th>Chapter Name</th>

                                        <th>Topic Name</th>

                                        <th>Topic Embed </th>

                                        <th>Topic Article</th>

                                        <th>Insert By</th>

                                        <th>Action</th>

                                    </tr>';

                                    

                                    $query=mysqli_query($con,'select chapter.chapter_name,topic.* from chapter RIGHT JOIN topic ON chapter.id = topic.chapter_id where topic.chapter_id = chapter.id');

                                    while($row=mysqli_fetch_assoc($query)){    

                                echo'<tr>

                                        <td>'.$row['chapter_name']. '</td>

                                        <td>'. $row['topic_name'].'</td>

                                        <td> '.$row['topic_embed'] .'</td>

                                        <td> '.$row['topic_article'].' </td>

                                        <td> '.$row['insert_by'].' </td>

                                <td><a href="topicupdate.php?id=' .$row['id'].'"><span class="glyphicon glyphicon-pencil"></span></a>/<a href="topicdelete.php?id='. $row['id'].'"><span class="glyphicon glyphicon-trash"></span></a></td>           

                                    </tr>';                

                                    

                                        } 

                                    

                                echo'</table>';

                                    }

                                    else{

                                echo'<table class="table table-bordered  table-striped">

                                    <tr>

                                        <th>Chapter Name</th>

                                        <th>Topic Name</th>

                                        <th>Topic Embed </th>

                                        <th>Topic Article</th>     

                                        <th>Action</th>

                                    </tr>';

                                    

                                    $query=mysqli_query($con,'select chapter.chapter_name,topic.* from chapter RIGHT JOIN topic ON chapter.id = topic.chapter_id where topic.chapter_id = chapter.id');

                                    while($row=mysqli_fetch_assoc($query)){ 

                                    echo'<tr>

                                            <td>'.$row['chapter_name']. '</td>

                                            <td>'. $row['topic_name'].'</td>

                                            <td> '.$row['topic_embed'] .'</td>

                                            <td> '.$row['topic_article'].' </td> 

                                            <td><a href="topicupdate.php?id=' .$row['id'].'"><span class="glyphicon glyphicon-pencil"></span></a></td>          

                                        </tr>';

                                        } 

                                    

                                echo' </table>';

                                    }

                            ?>    

                        </div>

                    </div>

                </div>

                <!-- end contact content -->

            </div>

        </div>

    </div>

    

</section>





<?php

include('includeFile/footer.php')

?>

