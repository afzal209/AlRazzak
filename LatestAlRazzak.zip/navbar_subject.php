<section id="mu-menu">
        <nav class="navbar navbar-default" role="navigation" style="background-color: whitesmoke;>
            <div class="container">
                <div class="navbar-header">
                    <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
                    <!-- LOGO -->
                    <!-- TEXT BASED LOGO -->
                    <a class="navbar-brand" href="index.php" style="style="color:#01bafd;"><span>Prephut</span></a>
                    <!-- IMG BASED LOGO  -->
                    <!-- <a class="navbar-brand" href="index.html"><img src="assets/img/logo.png" alt="logo"></a> -->
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                        <li ><a href="index.php" id="link">Home</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Subject <span class="fa fa-angle-down"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <?php
                                    include_once 'connect.php';
                                    @$query=mysqli_query($con,'select * from subject');
                                    while($row=mysqli_fetch_assoc($query)) {
                                ?>    
                                    <li><a href="topic.php?id=<?php echo $row['id'];?>"><?php echo $row['subject_name'];?></a></li>
                                <?php
                                    }
                                ?>
                            </ul>
                        </li>
                        <li><a href="#" id="link">Jobs Ads</a></li>
                        <li><a href="#" id="link">Updates</a></li>
                        <li><a href="#" id="link">Create Test</a></li>
                        <li><a href="#" id="link">Moke Test</a></li>
                       
                       

                        <!-- <li><a href="#" id="mu-search-icon"><i class="fa fa-search"></i></a></li> -->
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
        </nav>
    </section>