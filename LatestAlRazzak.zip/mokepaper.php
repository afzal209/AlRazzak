<?php  
    session_start();
    include_once 'function1.php';
    include('includeFile/header.php');
    ch_title("Moke Paper");

?>

<?php
    include_once 'includeFile/admin_navbar.php';     
    if(@$_GET['show_array'] == 1){
        echo '<pre>'.print_r($_SESSION,true).'</pre>';
    }
?>   
    <section id="mu-course-content" style="background-color: whitesmoke">
        <div class="container">
            <div class="row">
               
                <div class="col-md-12"> 
                   
                   <?php
                    $page = (isset($_GET['page'])) ? $_GET['page'] : 1;
                    
                     $questionPerPage = 1;
                     $startingQuestion = ($page * $questionPerPage) - $questionPerPage;
                     $id = $_GET['id'];
                     $a = 1;
                     $query=mysqli_query($con,"SELECT question.question,question.option1,question.option2,question.option3,question.option4,question.correct,questions_meta.* 
                     FROM question
                     RIGHT JOIN questions_meta ON question.id = questions_meta.question_id 
                     where meta_value = '$id'
                     ORDER BY questions_meta.meta_id ASC
                     LIMIT $startingQuestion, $questionPerPage
                 ");
                  @$totalCount=count($_SESSION['quiz']['questions']);
                  $correctCount=0;
                $query1=mysqli_query($con,"select count(*) as total from questions_meta where meta_value = '$id'");
                if(mysqli_num_rows($query) == 0){   
                    $query = mysqli_query($con,"select * from moke_title ");
                    $row = mysqli_fetch_assoc($query);
                    $r = $row['id'];
                    echo '<h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Notice</h1>
                    <h2 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Congratulations</h2>
                    <p class="text-center" style="margin-top:2%;font-size:20px;">Your Result will be shown .When paper time end .It will shown on Score Board</p>';
                    //echo 'nothing';
                    // echo '<h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Result</h1>
                    //         <h1 style="font-family: Arial, Helvetica, sans-serif;">Questions</h1>';
                    //  $query=mysqli_query($con,"SELECT question.question,question.option1,question.option2,question.option3,question.option4,question.correct,questions_meta.* 
                    //  FROM question
                    //  RIGHT JOIN questions_meta ON question.id = questions_meta.question_id 
                    //  where meta_value = '$id'");
                    
                    //  while($row=mysqli_fetch_assoc($query)){
                        
                    //             //  echo '<pre>'.print_r($_SESSION  ,true).'<pre>';
                    // //         //echo '<pre>'.print_r($row,true).'<pre>';
                    //         //echo $row['correct'];
                    //         if(@$row['correct'] == @$_SESSION['quiz']['questions'][$row['question_id']]){
                    //             $correctCount++;
                    //             $r = $row['meta_value'];
                    //         }
                    //        echo '<div class="col-md-12 col-sm-12">
                    //                 <h3 style="margin-left:5%;">'.$a++.'. '.$row['question'].'?</h3>
                    //             </div>
                    //             <div>
                    //                 <h1 style="font-family: Arial, Helvetica, sans-serif;margin-left:8%;">Answers '.$row['correct'].'</h1>
                    //             </div>';
                    //     }
                    // //     echo    '<h4 style="text-align: left;">Q '.$a++.': '. $row['question'].'</h4>
                    // //             <h6 style="text-align: left;">Input: '.$_SESSION['quiz']['questions'][$row['id']].'</h6>
                    // //             <h6 style="text-align: left;">Correct: '. $row['correct'].'</h6>';
                    // // }

                    //             echo '
                    //                 <div  class="col-md-12 col-sm-12 table-responsive" style="margin-top:2%;">
                    //                     <table class="table table-bordered  table-striped">
                    //                         <tr>
                    //                             <th>Total Question</th>
                    //                             <th>Wrong Answer</th>
                    //                             <th>Correct Answer</th>
                    //                         </tr>
                    //                         <tr>
                    //                             <td>'.$totalCount.'</td>
                    //                             <td>'. (int) ($totalCount-$correctCount).'  </td>
                    //                             <td>'.$correctCount.'</td>
                    //                         </tr>
                    //                     </table>
                    //                 </div>';

                                   echo' <a href="moke_session_finish.php" class="btn btn-default">Finish</a>';  
                    // echo 'Total Questions:'.$totalCount.'<br>';
                    // echo 'Correct Answers:'.$correctCount.'<br>';
                    // echo 'Wrong Answers:'. (int) ($totalCount-$correctCount).'<br>';
                }
                else{

                    
                    $query_moke =mysqli_query($con,"select time from moke_title where id='$id'");
                    $time="";
                    // $row_arr = array();
                    while($row=mysqli_fetch_array($query)){
                        $time = $row['time'];
                        $row1=mysqli_fetch_assoc($query1);
                        $row_moke = mysqli_fetch_assoc($query_moke); 
                        $_SESSION['time'] = $time;
                        $_SESSION['start_time'] =date("Y-m-d H:i:s");
                        
                        $end_time = date('Y-m-d H:i:s', strtotime('+'.$_SESSION["time"].'minutes',strtotime($_SESSION["start_time"])));
                        //   print_r($end_time);
                        $_SESSION['end_time'] = $end_time;
                        //echo '<pre>'.print_r($row,true).'<pre>';
                        //    $row_arr[] = $row;
                        //    shuffle($row_arr);
                        //    foreach ($row_arr as $key => $arr) {
                        //         print_r($arr['question']);
                        //    }  
                        // $row_arr = array($row['option1'],$row['option2'],$row['option3'],$row['option4']);
                        // shuffle($row_arr);
                        echo '
                          <h1 style="text-align: center; font-family: Arial, Helvetica, sans-serif;">Moke Test</h1>
                            <h3 style="text-align: right; font-family: Arial, Helvetica, sans-serif;" id="countdown"></h3>
                            <h3 style="text-align: right; font-family: Arial, Helvetica, sans-serif;">Date:'.$row['date'].'</h3>
                            
                            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                <hr>
                            </div>
                            <p style="text-align: center;font-size: 20px;" >Question '.$page.' of '.$row1['total'].' </p>
                            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                <hr>
                            </div>
                            <p style="font-size: 20px;">Q'.$page.' : '.$row['question'].'</p>
                            <div class="row" style="margin-left: 5%">
                                <form id="quizForm" name="quizForm" >';
                                // $i = 0 ;
                                // foreach ($row_arr as $key => $row_ar) {
                                //     ++$i;
                                
                                    for($i=1; $i<=4; $i++){
                                        
                                        echo '<div class="col-lg-6 col-xs-12 col-md-6 col-sm-12" class="form-group">
                                                <button type="button" class="btn btn-default btn_size" data-option="'.$row['option'.$i].'" id="option'.$i.'" name="option'.$i.'" onclick="SubmitQuestion(this,\'mokepaper.php?id='.@$id.'&page='.(@$page+1).'\');" >'.$row['option'.$i].'</button>
                                              </div>';
                                 }
                                // }
                                
    
                            echo    '<input type="hidden" value="'.@$row['correct'].'" id="correct_answer" name="correct_answer" />
                                    <input type="hidden" id="paperId" name="paperId" value="'.@$_GET['id'].'"/>
                                    <input type="hidden" id="questionId" name="questionId" value="'.@$row['question_id'].'"/> 
                                    <input type="hidden" id="social_user_id" name="social_user_id" value="'.@$_SESSION['userData']['id'].'"/> 
                                    <input type="hidden" id="end_time" name="end_time" value="'.@$end_time.'"/> 
                                    
                                </form>
                                
                            </div>';
                      }


                      
                }       
             
                   ?>
                    
                </div>
              
            </div>
        </div>
    </section>
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/snippets/mokepaper.js"></script>
    <script>
    setInterval(function() {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET", "response.php", false);
        xmlhttp.send(null);
        document.getElementById("countdown").innerHTML = xmlhttp.responseText;
    }, 1000);
    </script>
    <?php
         @include('includeFile/footer.php'); 
    ?>
