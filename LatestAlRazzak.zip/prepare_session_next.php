<?php 
$id = $_GET['id'];
// session_start();
// session_destroy();

// unset($_SESSION['quiz']['questions']);
header('location:preparechapter.php?id='.$id);

// exist();
?>