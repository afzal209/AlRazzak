<?php
include_once 'connect.php';
@include('includeFile/header.php');

ch_title("Jobs Info");
?>
<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
    </a>
    
    <?php
        @include_once 'includeFile/admin_navbar.php';
    ?>
    <section id="mu-course-content" style="background-color: white; padding: 18px 0;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Jobs Info</h1>
                    <div class="row">
                        <?php
                        include_once 'includeFile/company_name.php'; 
                        ?>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-top: 5px;">
                        <?php
                        
                        if(isset($_GET['id'])){
                            $id = $_GET['id'];
                            $query =mysqli_query($con,"select * from job_ads where organization_id = '$id' ");
                            while($row=mysqli_fetch_assoc($query)){
                            echo '<div>
                                    <a href="jobdetail.php?id='.$row['id'].'"><h1 style="font-family: Arial, Helvetica, sans-serif;font-size:15px;"><b>'.$row['job_title'].'</b><h1></a>
                                    <h1 style="margin-top:-3%"><a href="jobinfo.php?issue_date='.$row['issue_date'].'" style="font-size: 30% ;color:blue;">'.$row['issue_date'].'</a> <a href="jobinfo.php?source='.$row['source'].'" style="font-size: 30%;color:blue;" >'.$row['source'].'</a></h1>    
                                </div>'; 
                            }
                        }
                        elseif(isset($_GET['source'])){
                            $source = $_GET['source'];
                            $query =mysqli_query($con,"select * from job_ads where source = '$source' ");
                            while($row=mysqli_fetch_assoc($query)){
                            echo '<div>
                                    <a href="jobdetail.php?id='.$row['id'].'"><h1 style="font-family: Arial, Helvetica, sans-serif;font-size:15px;"><b>'.$row['job_title'].'</b><h1></a>
                                    <h1 style="margin-top:-3%"><a href="jobinfo.php?issue_date='.$row['issue_date'].'" style="font-size: 30% ;color:blue;">'.$row['issue_date'].'</a> <a href="jobinfo.php?source='.$row['source'].'" style="font-size: 30%;color:blue;" >'.$row['source'].'</a></h1>    
                                </div>'; 
                            }
                        }
                        elseif(isset($_GET['issue_date'])) {
                            $issue_date = $_GET['issue_date'];
                            $query =mysqli_query($con,"select * from job_ads where issue_date = '$issue_date' ");
                            while($row=mysqli_fetch_assoc($query)){
                            echo '<div>
                                    <a href="jobdetail.php?id='.$row['id'].'"><h1 style="font-family: Arial, Helvetica, sans-serif;font-size:15px;"><b>'.$row['job_title'].'</b><h1></a>
                                    <h1 style="margin-top:-3%"><a href="jobinfo.php?issue_date='.$row['issue_date'].'" style="font-size: 30% ;color:blue;">'.$row['issue_date'].'</a> <a href="jobinfo.php?source='.$row['source'].'" style="font-size: 30%;color:blue;" >'.$row['source'].'</a></h1>    
                                </div>'; 
                            }
                        }
                        elseif(isset($_GET['city'])) {
                            $city = $_GET['city'];
                            $query =mysqli_query($con,"select job_ads.*,job_info.* from job_ads inner join job_info on job_ads.id = job_info.job_ads_id where job_info.city = '$city' ");
                            while($row=mysqli_fetch_assoc($query)){
                            echo '<div>
                                    <a href="jobdetail.php?id='.$row['id'].'"><h1 style="font-family: Arial, Helvetica, sans-serif;font-size:15px;"><b>'.$row['job_title'].'</b><h1></a>
                                    <h1 style="margin-top:-3%"><a href="jobinfo.php?issue_date='.$row['issue_date'].'" style="font-size: 30% ;color:blue;">'.$row['issue_date'].'</a> <a href="jobinfo.php?source='.$row['source'].'" style="font-size: 30%;color:blue;" >'.$row['source'].'</a> <a href="jobinfo.php?city='.$row['city'].'" style="font-size: 30%;color:blue;" >'.$row['city'].'</a></h1>    
                                </div>';    
                            }
                        }
                        elseif(isset($_GET['provinces'])) {
                            $provinces = $_GET['provinces'];
                            $query =mysqli_query($con,"select job_ads.*,job_info.* from job_ads inner join job_info on job_ads.id = job_info.job_ads_id where job_info.provinces = '$provinces' ");
                            while($row=mysqli_fetch_assoc($query)){
                            echo '<div>
                                    <a href="jobdetail.php?id='.$row['id'].'"><h1 style="font-family: Arial, Helvetica, sans-serif;font-size:15px;"><b>'.$row['job_title'].'</b><h1></a>
                                    <h1 style="margin-top:-3%"><a href="jobinfo.php?issue_date='.$row['issue_date'].'" style="font-size: 30% ;color:blue;">'.$row['issue_date'].'</a> <a href="jobinfo.php?source='.$row['source'].'" style="font-size: 30%;color:blue;" >'.$row['source'].'</a> a href="jobinfo.php?provinces='.$row['provinces'].'" style="font-size: 30%;color:blue">'.$row['provinces'].'</a></h1>    
                                </div>';    
                            }
                        }
                        ?>
                           
                         
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
<?php    
    include('includeFile/footer.php');
?>
