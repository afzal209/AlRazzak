<?php
    require_once 'facebookLogin/config.php';

    if (isset($_SESSION['access_token'])) {
            header("location: mokelist.php");
    }

    $redirectUrl= "https://www.prephut.net/facebookLogin/fb-callback.php";
    $permission = ['email'];
    $loginUrl  = $helper->getLoginUrl($redirectUrl,$permission);
    //echo $loginUrl;


?>

<?php
ob_start(); 
include_once 'includeFile/header.php';
ch_title("Social Login");
include_once 'includeFile/admin_navbar.php';
?>

<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Social Login</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="" action="">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                    echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }

                                        ?>        
                                        <p class="form-submit">
                                            <input type="button" value="Login With Facebbok" onclick="window.location = '<?php echo $loginUrl?>';" class="mu-post-btn" name="facebook">
                                        </p>
                                        <p class="comment-form-author">
                                            <h1>Or</h1>
                                        </p> 
                                        <p class="form-submit">
                                            <input type="button" value="Login With Twitter" class="mu-post-btn" name="twitter">
                                        </p>
                                        <p class="comment-form-author">
                                            <h1>Or</h1>
                                        </p>
                                        <p class="form-submit">
                                            <input type="button" value="Login With Google" class="mu-post-btn" name="google">
                                        </p>    
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>


<?php
include('includeFilefooter.php')
?>

<?php

    

?>