<?php
include_once 'connect.php';
@include('includeFile/header.php');

ch_title("Score Board");
?>
<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
    </a>
    
    <?php
        @include_once 'includeFile/admin_navbar.php';
    ?>
    <section id="mu-course-content" style="background-color: white; padding: 18px 0;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">Score Board</h1>
                    <div class="row">
                       
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-top: 5px;">
                       
                            <div  class="col-md-12 col-sm-12 table-responsive" style="margin-top:2%;">
                                    <table class="table table-bordered  table-striped">
                                        <tr>
                                            <th>S No</th>
                                            <th>Job Title</th>
                                        </tr>
                                        <?php
                                        $query = mysqli_query($con,"select * from moke_title");
                                        while($row=mysqli_fetch_assoc($query)){
                                   echo'<tr>
                                            <td>'.$row['id'].'</td>
                                            <td><a href="scorelist.php?id='.$row['id'].'">'.$row['job_title'].'</a></td>   
                                            
                                        </tr>';
                                        }
                                        ?>
                                 </table>
                            </div>
                         
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
<?php    
    include('includeFile/footer.php');
?>
