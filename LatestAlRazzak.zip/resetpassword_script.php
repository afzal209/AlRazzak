


<?php 
if (isset($_POST['submit'])) {
    include 'connect.php';
    $email=$_POST['email'];
    $token=$_POST['token'];
    $new=$_POST['newpassword'];
    $confirm=$_POST['confirmpassword'];

    if ($new == $confirm) {
        $query=mysqli_query($con,"update user set password='$new',token='' where email='$email'");
        echo $query;
        if ($query == 1) {
            //echo $query;
        	header('location: login.php?response=success&class=success&message=Password Change Successfully!');
        } else {
            //echo $query;

        	header('location: forgetpassword.php?response=error&class=danger&message=Kindly forgot Password Again');
        }
        
    } else {
        header('location: resetpassword.php?token='.$token.'&email='.$email.'&response=error&class=danger&message=Password not Match!');
    }

} 


?>