<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>

<?php
include_once 'includeFile/header.php';
ch_title("View Question");
include_once 'includeFile/admin_navbar.php';
?>





<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>View Question</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div  class="col-md-12 col-sm-12 table-responsive" >
                            <?php
                                 
                                 if(@$_GET['response'] != ''){
                                echo '  <div class="alert alert-'.@$_GET['class'].'">
                                         <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                     </div>';
                                 }
                                 
                                 
                                if($_SESSION['user']['role'] == 'admin'){  
                                echo'<table class="table table-bordered  table-striped">
                                    <tr>
                                        <th>Topic</th>
                                        <th>Question</th>
                                        <th>Correct </th>
                                        <th>Option 1</th>
                                        <th>Option 2</th>
                                        <th>Option 3</th>
                                        <th>Option 4</th>
                                        <th>Insert By</th>
                                        <th>Action</th>
                                    </tr>';
                                    
                                        $query=mysqli_query($con,'select topic.topic_name,question.* from topic RIGHT JOIN question ON topic.id = question.topic_id where question.topic_id = topic.id');
                                        while($row=mysqli_fetch_assoc($query)){ 
                                         
                                        echo '<tr>
                                            <td>'.$row['topic_name']. '</td>
                                            <td>'. $row['question'].'</td>
                                            <td> '.$row['correct'] .'</td>
                                            <td> '.$row['option1'].' </td>
                                            <td> '.$row['option2'].' </td>
                                            <td> '.$row['option3'].' </td>
                                            <td> '.$row['option4'].' </td>
                                            <td> '.$row['insert_by'].'</td>
                                            <td><a href="questionupdate.php?id=' .$row['id'].'"><span class="glyphicon glyphicon-pencil"></span></a>/<a href="questiondelete.php?id='. $row['id'].'"><span class="glyphicon glyphicon-trash"></span></a></td>        
                                        </tr>';
                                    
                                        } 
                                    
                               echo' </table>';
                                    }
                                    else{
                                        echo'<table class="table table-bordered  table-striped">
                                        <tr>
                                            <th>Topic</th>
                                            <th>Question</th>
                                            <th>Correct </th>
                                            <th>Option 1</th>
                                            <th>Option 2</th>
                                            <th>Option 3</th>
                                            <th>Option 4</th>
                                            <th>Action</th>
                                        </tr>';
                                        
                                            $query=mysqli_query($con,'select topic.topic_name,question.* from topic RIGHT JOIN question ON topic.id = question.chapter_id where question.chapter_id = topic.id');
                                            while($row=mysqli_fetch_assoc($query)){ 
                                             
                                            echo '<tr>
                                                <td>'.$row['topic_name']. '</td>
                                                <td>'. $row['question'].'</td>
                                                <td> '.$row['correct'] .'</td>
                                                <td> '.$row['option1'].' </td>
                                                <td> '.$row['option2'].' </td>
                                                <td> '.$row['option3'].' </td>
                                                <td> '.$row['option4'].' </td>
                                                <td><a href="questiondelete.php?id='. $row['id'].'"><span class="glyphicon glyphicon-trash"></span></a></td>        
                                            </tr>';
                                        
                                            } 
                                        
                                   echo' </table>';
                                    }
                            ?>    
                        </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>


<?php
include('includeFile/footer.php')
?>
