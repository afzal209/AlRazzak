<?php
    include_once 'connect.php';
    @include('includeFile/header.php');
    ch_title("Topic List");

    
?>

<a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
</a>

 <!-- Start menu -->
<?php
    include_once 'includeFile/admin_navbar.php';
?>

<section id="mu-course-content" style="background-color: white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php
                        @$id=$_GET['id'];
                        $query=mysqli_query($con,"select chapter_name from chapter where id='$id'");
                        $row=mysqli_fetch_assoc($query);
                        echo '  <h1 class="text-center" style="font-family: Arial, Helvetica, sans-serif;">'.$row['chapter_name'].'</h1>
                                <h1 style="font-family: Arial, Helvetica, sans-serif;">Topic List</h1>';
                    ?>     
                </div>
                <div class="col-md-12 col-sm-12">
                    <ol class="cs">
                        <?php
                            // if(isset($_GET['page'])){
                            //     @$page = $_GET['page'];
                            // }
                            // else{
                            //     $page = 1;
                            // }
                            // $num_per_page = 05;
                            // $start_from = ($page-1)*05;
                            //echo $start_from;

                            @$id=$_GET['id'];
                            $a=1;
                            //$query=mysqli_query($con,"select * from chapter where subject_id='$id' limit $start_from,$num_per_page");
                            $query=mysqli_query($con,"select * from topic where chapter_id='$id' ");                            
                            if(mysqli_num_rows($query) > 0){
                                while($row=mysqli_fetch_assoc($query)){
                                    echo '<li><a href="topic.php?id='.$row['id'].'" >'.$row['topic_name'].'</a></li>';
                                }
                            }
                            else{
                                echo 'No Topic Found';
                                } 
                        ?>
                    </ol>
                </div>
            </div>
            <!-- <div class="mu-pagination">
                <nav>
                    <ul class="pagination"> -->
                        <?php 
                            //  @$id=$_GET['id'];
                            //  $a=1;
                            //  $pr_query=mysqli_query($con,"select * from chapter where subject_id='$id' ");
                            //  $total_num= mysqli_num_rows($pr_query);
                            //  //echo $total_num;
                            //  $total_page = ceil($total_num/$num_per_page);
                            //  //echo $total_page; 
                              
                                
                            //         if($page>1){
                            //             echo'<li>
                            //                     <a href="chapters.php?page='.($page - 1).'&id='.$id.'" aria-label="Previous">
                            //                         <span class="fa fa-angle-left"></span> Prev
                            //                     </a>
                            //                 </li>';
                            //         }
                            //         for ($i=1; $i<=$total_page ; $i++) {
                            //             echo '<li><a href="chapters.php?page='.$i.'&id='.$id.'">'.$i.'</a></li>';
                            //         }
                            //         if($i>$page){
                            //             echo '<li>
                            //                 <a href="chapters.php?page='.($page + 1).'&id='.$id.'" aria-label="Next">
                            //                     Next <span class="fa fa-angle-right"></span>
                            //                 </a>
                            //             </li>';
                            //         }
                        ?>
                    <!-- </ul>
                </nav>
            </div> -->
        </div>
    </section>




<?php 
    @include('includeFile/footer.php')
?>