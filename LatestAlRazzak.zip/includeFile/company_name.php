<div class="col-lg-12 col-md-12 col-sm-12">
                            <ul class="picslistTp">
                                <?php
                                include 'connect.php';
                                $query = mysqli_query($con,"select * from organization limit 14");
                                while($row=mysqli_fetch_assoc($query)){
                                    echo '
                                    <li class="channelBlockList">
                                        <a href="jobinfo.php?id='.$row['id'].'"><img src="logo/'.$row['organization_image'].'" class="image-small"  width="50" height="50" alt="">
                                            '.$row['organization_name'].'
                                        </a>
                                    </li>';
                                } 
                                ?>
                                
                                
                               
                            </ul>   
                        <!-- <div class="box">
                                <a href=""><img src="assets/img/govt_logo.png"  width="50" height="42" alt=""></a>
                                <a href="" style="margin-top: 2px;">Govt Sindh</a>
                           </div>
                           <div class="box">
                                <a href=""><img src="assets/img/govt_logo.png" width="42" height="42" alt=""></a>
                           </div>
                           <div class="box">
                                <a href=""><img src="assets/img/govt_logo.png" width="42" height="42" alt=""></a>
                           </div>
                           <div class="box">
                                <a href=""><img src="assets/img/govt_logo.png" width="42" height="42" alt=""></a>
                           </div>
                           <div class="box">    
                                <a href=""><img src="assets/img/govt_logo.png" width="42" height="42" alt=""></a>
                           </div>
                           <div class="box">
                                <a href=""><img src="assets/img/govt_logo.png" width="42" height="42" alt=""></a>
                           </div>
                           <div class="box">
                                <a href=""><img src="assets/img/govt_logo.png" width="42" height="42" alt=""></a>
                           </div>
                           <div class="box">
                                <a href=""><img src="assets/img/govt_logo.png" width="42" height="42" alt=""></a>
                           </div>
                           <div class="box">
                                <a href=""><img src="assets/img/govt_logo.png" width="42" height="42" alt=""></a>
                           </div>
                           <div class="box">
                                <a href=""><img src="assets/img/govt_logo.png" width="42" height="42" alt=""></a>
                           </div>
                           <div class="box">
                                <a href=""><img src="assets/img/govt_logo.png" width="42" height="42" alt=""></a>
                           </div> -->
                           
    </div>