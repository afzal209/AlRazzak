<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AlRazzak | Home</title>
    <?php require "title_script.php"; ?>
    <!-- Favicon -->
    <?php
     @include('css.php')
     ?>
      <style>
      #link{
        color:black;
      }
     
      .change{
        margin-left:19%;
      }
      .cs{
        font-size: 30px;
        font-family: Arial, Helvetica, sans-serif;
        margin-left: 5%;  
      }
      .cs 
      #txt{
        text-align: center;
      }
      #txt1{
          margin-left: 15%; 
      }
      .btn_size{
        padding: 20px 30px;
        border-radius: 10px;
        margin-top: 5%;
        font-size: 15px;
      }
      #m-footer {
        display: inline;
        float: left;
        width: 100%;
        
       
      }
      #m-footer .m-footer-bottom {
          background-color: #222;
          display: inline;  
          float: left;
          padding: 25px 0;
          width: 100%;
      }
      #m-footer .m-footer-bottom .m-footer-bottom-area {
          display: inline;
          float: left;
          text-align: center;
          width: 100%;
      }
      #m-footer .m-footer-bottom .m-footer-bottom-area p {
          color: #fff;
          margin-bottom: 0;
          letter-spacing: 0.3px;
      }

      #m-footer .m-footer-bottom .m-footer-bottom-area p a {
          color: #fff;
      }
       #iframe-container{
        position: relative;
        width: 100%;
        padding-bottom: 40%;
        height: 0;
      }
      #iframe-container iframe{
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
      }
      th {
        font-size: 20px;
      }
      td{
        text-align: center;
      }
      
      #remove_border{
        background-color: transparent;
        border: 0px solid;
        
        
      }
      .dropdown-submenu {
        position: relative;
      }

      .dropdown-submenu .dropdown-menu {
        top: 0;
        left: 0;
        margin-top: 25%;
      }
      .box-job {
        width: 100%;
        padding: 10px;
        border: 2px solid lightpink;
        margin: 1px;
      }
      .box-job-content {
        width: 50%;
        padding: 10px;
        border: 2px solid lightpink;
        margin: 1px;
      }
      .box-job:hover{
         background: whitesmoke;
      }
      .box-job h6{
        color: #959595 ;
      }
      .picslistTp{
        list-style-type: none;
        padding-left: 2%;
        padding-right: 2%;
        margin: 0 auto;
        width: 100%;
        height: auto;
        list-style: none;
      }
      .channelBlockList{
        float: left;
        padding: 7px;
        margin: 3px;
        width: 68px;
        height: 80px;
        border-radius: 3px;
        background: #efefef;
        box-shadow: 0 0 1px 0 rgba(0,0,0,.1);
        line-height: 1.2em;
        text-align-last: center;
      }
      .channelBlockList a {
        font-size: .7em;
        color: #333;
      }
      .img.image-small, a:visited img.image-small {
        background: #fff;
        padding: 3px;
        border: 1px solid #cfcfcf;
        box-shadow: 0 0 1px 0 rgba(0,0,0,.1);
      }
        a img.image-small, a:link img.image-small {
          background: #fff;
          padding: 3px;
          border: 1px solid #cfcfcf;
     }
     .topjobs li {
       margin-top: 5px;
     }
      .header-middle{
        padding-top: 20px;
        padding-bottom: 20px;
      }

      .header-middle .contact {
        display: block;
        padding: 8px 0 0 0;
        float: right;
        margin-top: 3%;
      }

      .header-middle .contact ul {
        display: block;
        padding-right: 32px;
        float: left;
      }
      .header-middle .contact ul li {
        display: block;
        padding: 0 30px;
        border-right: 1px #dedddd solid;
        float: left;
        font-family: 'texgyreadventorbold';
        font-size: 18px;
        color: #4f4a4a;
        line-height: 18px;
      }
      .header-middle .contact ul li span {
        display: block;
        font-family: 'Roboto', sans-serif;
        font-size: 12px;
        color: #8f9ba1;
        text-transform: uppercase;
      }
      .header-middle .contact ul li a {
        color: #4f4a4a;
      }
      .header-middle .contact ul li a:hover {
        color: #ff9600;
      }

      .navbar {
          border-radius: 0px;
          margin: 0px;
          border: none;
      }
      .navbar-inverse {
          background: #17a43b;
      }
      .navbar .dropdown a:link{
        color:black;
      }
      .navbar .dropdown a:active{
        color:white;
      }
       .header-middle a.login {
          display: inline-block;
          padding: 5px 20px;
          border: 2px #2c97ea solid;
          border-radius: 5px;
          font-size: 12px;
          color: #6f7a7f;
          font-weight: 700;
      }
      .header-middle a.login:hover {
        background: #2c97ea;
        color: #fff;
      }
      .header-middle a.login span {
        display: inline-block;
        vertical-align: middle;
        margin-top: -2px;
        margin-left: 10px;
        font-size: 14px;
        color: #00aaff;
      }
      .header-middle a.login:hover span {
        color: #fff;
      }
      .jb_h1{
            margin-top: -4%;
        }
        
      @media screen and (max-width: 500px){
        .header-middle a.login {
          margin-top: 8%;
        }
        .jb_main .jb_cis .jb_h1{
            margin-top: -10%;
        }
      }
      </style>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>