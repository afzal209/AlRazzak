<script src="assets/js/jquery.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->

    <script src="assets/js/bootstrap.js"></script>

    <!-- Slick slider -->

    <script type="text/javascript" src="assets/js/slick.js"></script>

    <!-- Counter -->

    <script type="text/javascript" src="assets/js/waypoints.js"></script>

    <script type="text/javascript" src="assets/js/jquery.counterup.js"></script>

    <!-- Mixit slider -->

    <script type="text/javascript" src="assets/js/jquery.mixitup.js"></script>

    <!-- Add fancyBox -->

    <script type="text/javascript" src="assets/js/jquery.fancybox.pack.js"></script>



    <!-- Sweet alert -->

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Custom js -->

    <script src="assets/js/custom.js"></script>



    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>-->
    
    <script src="DataTables-1.10.18/js/jquery.dataTables.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="bootstrap-select/dist/js/bootstrap-select.min.js"></script>
     <script>
        $(document).ready(function(){
        $('.dropdown-submenu a.test').on("click", function(e){
            $(this).next('ul').toggle();
            e.stopPropagation();
            e.preventDefault();
        });
        });
    </script>