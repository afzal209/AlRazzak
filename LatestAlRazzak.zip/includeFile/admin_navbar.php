 <?php
ob_start(); 
?>
<header id="mu-header" style="background: black;">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mu-header-area">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="mu-header-top-left">
                  <!-- <div class=" ">
                    <i class="fa fa-envelope"></i>
                    <span>info@markups.io</span>
                  </div> -->
                  <!-- <div class="mu-top-phone">
                    <i class="fa fa-phone"></i>
                    <span>(568) 986 652</span>
                  </div> -->
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="mu-header-top-right">
                  <nav>
                    <ul class="mu-top-social-nav">
                      <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                      <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                      <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                      <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                      <li><a href="#"><span class="fa fa-youtube"></span></a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <div class="container header-middle">
      <div class="row">
            <span class="col-xs-6 col-sm-3">
              <a href="index.php"> <img src="assets/logo/govt_logo.png" alt="error" class="img-responsive" width="30%" height="30%" style="margin-top: 5%;"> </a>
            </span>
             <!-- <div class="col-xs col-sm-9"> -->
               <div class="col-xs-6 col-sm-9">
                <div class="contact clearfix">
                    <ul class="hidden-xs">
                        <li>
                            <span>Email</span>    
                            <a href="">info@markups.io</a>
                        </li>
                        <li>
                            <span>Phone Number</span>
                            0313 324 5047   
                        </li>
                    </ul>
                    <a href="" class="login">
                        Student Login
                        <span class="fa fa-play-circle"></span>
                    </a>
                </div>
                
              
            </div>  
            <!-- </div> -->
      </div>
  </div>
<section id="mu-menu">
        <nav class="navbar navbar-inverse" role="navigation" >
            <div class="container">
                <div class="navbar-header">
                    <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar" style="background:#17a43b;">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
                    <!-- LOGO -->
                    <!-- TEXT BASED LOGO -->
                   <!--<a class="navbar-brand" href="index.php" style="color:#01bafd;"><span>Prephut</span></a>-->
                    <!-- IMG BASED LOGO  -->
                    <!-- <a class="navbar-brand" href="index.html"><img src="assets/img/logo.png" alt="logo"></a> -->
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul id="top-menu" class="nav navbar-nav  main-nav" id="myUL">
                        <li ><a href="index.php" id="link">Home</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" >Academic <span class="fa fa-angle-down"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <?php
                                    include_once 'connect.php';
                                    @$query=mysqli_query($con,"select * from academic where insert_type = 'academic'");
                                    if (mysqli_num_rows($query) > 0) {
                                        while($row=mysqli_fetch_assoc($query)) {    # code...
                                ?>    
                                <li><a href="subject.php?id=<?php echo $row['id'];?>&insert_type=<?php echo $row['insert_type']?>"><?php echo $row['academic_name'];?></a></li>
                                <?php
                                    }
                                }
                                else{
                                ?>
                                <li>No Subject Added</li>
                                <?php    
                                }
                                ?>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" >Entry Test<span class="fa fa-angle-down"></span></a>
                            <ul class="dropdown-menu" role="menu">
                            <?php
                                    include_once 'connect.php';
                                    @$query=mysqli_query($con,"select * from academic where insert_type = 'entrytest'");
                                    if (mysqli_num_rows($query) > 0) {
                                        while($row=mysqli_fetch_assoc($query)) {    # code...
                                ?>    
                                <li><a href="subject.php?id=<?php echo $row['id'];?>&insert_type=<?php echo $row['insert_type']?>"><?php echo $row['academic_name'];?></a></li>
                                <?php
                                    }
                                }
                                else{
                                ?>
                                <li>No Subject Added</li>
                                <?php    
                                }
                                ?>
                            </ul>   
                        </li>
                        <li><a href="preparesubject.php" id="link">Test Preparation</a></li>
                        <li><a href="mokelist.php" id="link">Moke Test</a></li>
                        <li><a href="#" id="link">New Update</a></li>
                        <li><a href="jobsads.php" id="link">Jobs Ad</a></li>
                        <li><a href="scoreboard.php" id="link">Score Board</a></li>
                        
                        <?php
                        if(@$_SESSION['user']['email'] != '' && @$_SESSION['user']['password'] != '' ){
                        ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" ><?php echo @$_SESSION['user']['username']; ?> <span class="fa fa-angle-down"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <?php
                                    if (@$_SESSION['user']['role'] == 'admin') {     
                                ?>
                                <li class="dropdown-submenu">
                                    <a class="test" tabindex="-1" href="#">User <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a tabindex="-1"  href="viewuser.php">View User</a></li>
                                        <li><a tabindex="-1" href="adduser.php">Add User</a></li>
                                        
                                    </ul>
                                </li>
                                <li><a href="addacademic.php">Add Academic</a></li>
                                <li><a href="addsubject.php">Add Subject</a></li>
                                <li class="dropdown-submenu">
                                    <a class="test" tabindex="-1" href="#">Chapter <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a tabindex="-1"  href="viewchapter.php">View Chapter</a></li>
                                        <li><a tabindex="-1" href="addchapter.php">Add Chapter</a></li>
                                    </ul>
                                </li>
                                 <li class="dropdown-submenu">
                                    <a class="test" tabindex="-1" href="#">Topic <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a tabindex="-1"  href="viewtopic.php">View Topic</a></li>
                                        <li><a tabindex="-1" href="addtopic.php">Add Topic</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown-submenu">
                                    <a class="test" tabindex="-1" href="#">Question <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a tabindex="-1"  href="viewquestion.php">View Question</a></li>
                                        <li><a tabindex="-1" href="addquestion.php">Add Question/Answer</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown-submenu">
                                    <a class="test" tabindex="-1" href="#">Moke <span class="caret"></span></a>
                                    <ul class="dropdown-menu" >
                                        <li><a tabindex="-1"  href="addmoke.php">Add Moke Test</a></li>
                                        <li><a tabindex="-1" href="adminacademic.php">Admin Academic</a></li>
                                        <!--<li><a tabindex="-1" href="mokelist.php">Moke List</a></li>-->
                                      
                                    </ul>
                                </li>
                                <li><a href="testsubject.php">Test Subject</a></li>
                                <li><a href="testchapter.php">Test Chapter</a></li>
                                <li><a href="testtopic.php">Test Topic</a></li>
                                <li><a href="testquestion.php">Test Question</a></li>
                                <li><a href="addjob.php">Add Job</a></li>
                                <li><a href="addjobinfo.php">Add Job Info</a></li>
                                <li><a href="logout.php">Logout</a></li>                                                      
                                <?php        
                                     }
                                    elseif (@$_SESSION['user']['role'] == 'editor') {
                                ?>
                                <li class="dropdown-submenu">
                                    <a class="test" tabindex="-1" href="#">Topic <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a tabindex="-1"  href="viewtopic.php">View Topic</a></li>
                                        <li><a tabindex="-1" href="addtopic.php">Add Topic</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown-submenu">
                                    <a class="test" tabindex="-1" href="#">Question <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a tabindex="-1"  href="viewquestion.php">View Question</a></li>
                                        <li><a tabindex="-1" href="addquestion.php">Add Question/Answer</a></li>
                                    </ul>
                                </li>
                                <li><a href="logout.php">Logout</a></li>
                                <?php
                                      }
                                     elseif(@$_SESSION['user']['role'] == 'subadmin'){ 
                                ?>
                                <li class="dropdown-submenu">
                                    <a class="test" tabindex="-1" href="#">Moke <span class="caret"></span></a>
                                    <ul class="dropdown-menu" >
                                        <li><a tabindex="-1"  href="addmoke.php">Add Moke Test</a></li>
                                        <li><a tabindex="-1" href="adminacademic.php">Admin Academic</a></li>
                                        <!--<li><a tabindex="-1" href="mokelist.php">Moke List</a></li>-->
                                      
                                    </ul>
                                </li>
                                <li><a href="logout.php">Logout</a></li>
                                <?php    
                                }
                                ?>
                            </ul>
                        </li>
                       <?php
                        }
                        elseif (@$_SESSION['userData']['email'] != '') {
                                ?>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo @$_SESSION['userData']['first_name']; ?> <span class="fa fa-angle-down"></span></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="facebookLogin/logout.php">Logout</a></li>
                                    </ul>
                                </li>
                                <?php 
                                }   
                        ?>
                        
                       

                        <!-- <li><a href="#" id="mu-search-icon"><i class="fa fa-search"></i></a></li> -->
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
        </nav>
    </section>

