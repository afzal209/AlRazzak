<?php
ob_start();
session_start();
$con=mysqli_connect('localhost','AlRazzak','AlRazzak123!@#','AlRazzak');


// if($con){
//     echo "<script>alert('connect')</script>";
// }
// else{
//     echo "<script>alert('not connect')</script>";
// }


?>