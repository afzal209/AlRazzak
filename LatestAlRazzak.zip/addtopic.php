<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>
<?php
    
     $session_permission = $_SESSION['user']['academic_id'];
    //echo '<pre>'.print_r($session_permission_sub,true).'</pre>';
    $session_permission_sub = $_SESSION['user']['subject_id'];
    //echo '<pre>'.print_r($session_permission_sub,true).'</pre>';
    // //echo $session_var;
    //echo '<pre>'.print_r($session_permission_sub,true).'</pre>';
    $session_permission_ex = explode(',' ,$session_permission_sub);
    //echo '<pre>'.print_r($session_permission_ex,true).'</pre>';
    $session_permission_im = "'".implode(",",$session_permission_ex)."'";
    //echo '<pre>'.print_r($session_permission_im,true).'</pre>';
    $session_role = $_SESSION['user']['role'];

    $session_role_ex = explode(',',$session_role);

    $session_role_im = "'".implode("",$session_role_ex)."'";
    //echo '<pre>'.print_r($session_permission,true).'</pre>';

    // //echo $session_permission;
    $where = "";
    if($_SESSION['user']['role'] == 'editor'){
        $where = "where id IN ($session_permission)";
    }
    $query=mysqli_query($con,"select * from academic $where");
    $resultAcademics = array();
    while($row=mysqli_fetch_assoc($query)){
        $resultAcademics[] = $row;
    }
    //echo '<pre>'.print_r($resultAcademics,true).'</pre>';
?>
<?php
include_once 'includeFile/header.php';
ch_title("Add Topic");
include_once 'includeFile/admin_navbar.php';
?>

<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Add Topic</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="phpScript/topic_script.php" enctype="multipart/form-data">
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                             echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }

                                        ?>
                                         <p class="comment-form-author">
                                            <label for="academic">Choose Academic<span class="required">*</span></label>
                                            <select class="form-control"  name="academic" id="academic">
                                                <option value=""></option>
                                            <?php 
                                                foreach($resultAcademics as $key=>$academic){
                                                    echo '<option value="'.$academic['id'].'" > '.$academic['academic_name'].' </option>';
                                                }
                                            ?>
                                            </select>
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="subject">Choose Subject <span class="required">*</span></label>
                                            <select name="subject" id="subject" class="form-control">
                                            </select>
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="chapter">Choose Chapter <span class="required">*</span></label>
                                            <select name="chapter" id="chapter" class="form-control">
                                                <option value=""></option>
                                            </select>
                                        </p>
                                         <p class="comment-form-author">
                                            <label for="name">Topic Name <span class="required">*</span></label>
                                            <input type="text"  size="30" value="" name="name">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="video">Video Link <span class="required">*</span></label>
                                            <input type="text"   value="" name="video">
                                        </p>
                                        <p class="comment-form-comment">
                                            <label for="article">Article</label>
                                            <textarea  aria-required="true" rows="8" cols="45" name="article"></textarea>
                                        </p>
                                        <input type="hidden" name="insert_by" value="<?php echo @$_SESSION['user']['username']; ?>" >             
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type="text/javascript">
    $(document).ready(function(e){
        $('#academic').on('change', function(e){
            //console.log(e);
            var aca_id = e.target.value;
              var sub_hd = <?php echo $session_permission_im?>;
            var role_hd = <?php echo $session_role_im?>
            //console.log(aca_id);
            $.get('ajax/topicServer.php?id='+aca_id+'&sub_hd='+sub_hd+'&role_hd='+role_hd, function(data){
                //console.log(data);
                var result = JSON.parse(data);
                //console.log(result);
                $('#subject').empty();
                 $('#subject').append('<option value = ""></option>');  
                 for(var i=0 ;i<result.length ; i++ ){
                     //console.log(result[i].id);
                     $('#subject').append('<option value = "'+result[i].id+'">'+result[i].subject_name+'</option>');
                 }
            });
        });
        $('#subject').on('change', function(e){
            //console.log(e);
            var sub_id = e.target.value;
            //console.log(aca_id);
            $.get('ajax/topicServer1.php?id='+sub_id, function(data_s){
                //console.log(data);
                var result = JSON.parse(data_s);
                //console.log(result);
                 $('#chapter').empty();
                 for(var i=0 ;i<result.length ; i++ ){
                     //console.log(result[i].id);
                     $('#chapter').append('<option value = "'+result[i].id+'">'+result[i].chapter_name+'</option>');
                 }
            });
        });
    });
</script>
<?php
include('includeFile/footer.php')
?>
