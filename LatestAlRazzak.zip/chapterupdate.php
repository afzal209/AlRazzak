<?php 
include 'phpGetId/chapter_getId.php';
ob_start();
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>





<?php

include_once 'includeFile/header.php';
ch_title("Update Chapter");
include_once 'includeFile/admin_navbar.php';
?>



<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Update Chapter</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="" >
                                        
                                       
                                         <p class="comment-form-author">
                                            <label for="name">Chapter Name <span class="required">*</span></label>
                                            <input type="text"  size="30" value="<?php echo $name;?>" name="name">
                                        </p>
                                       
                                        <p class="form-submit">
                                            <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>


<?php
include('includeFile/footer.php')
?>


<?php

include('phpScript/update_chapter_script.php');

?>