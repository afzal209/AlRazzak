<?php

include 'connect.php';
if (isset($_GET['id'])) {
    $id=$_GET['id'];
    $query=mysqli_query($con,"select user.*,user_permission.*,subject.*,academic.*,academic.academic_name as academy, group_concat( subject.subject_name ) AS subject_concat from user left join user_permission on user.id = user_permission.user_id LEFT JOIN subject ON subject.id = user_permission.permission_sub LEFT JOIN academic ON academic.id = user_permission.permission where user.id = '$id'");

    
    $row=mysqli_fetch_assoc($query);

    //echo '<pre>'.print_r($row,true).'</pre>';
    $username = $row['username'];
    $email = $row['email'];
   $permission = $row['academic_name'];
    $permission_sub = $row['subject_concat'];
    $role = $row['role'];    # code...
    $permissionArray = explode(",", $row['subject_concat']);
     $permissionArr = explode(",",$row['academy']);
}
else {
    header("location:viewuser.php");
} 

?>