<?php
include 'connect.php';
if(isset($_GET['id'])){
    $id=$_GET['id'];
    $query=mysqli_query($con,"select * from question where id='$id'");
    $row=mysqli_fetch_assoc($query);
    $question=$row['question'];
    $option1=$row['option1'];
    $option2=$row['option2'];
    $option3=$row['option3'];
    $option4=$row['option4'];
    $correct=$row['correct'];
    
} 
?>