<?php
include 'connect.php';
if(isset($_GET['id'])){
    $id=$_GET['id'];

    $query=mysqli_query($con,"select * from chapter where id='$id'");
    $row=mysqli_fetch_assoc($query);
    $name=$row['chapter_name'];
    
} 
?>