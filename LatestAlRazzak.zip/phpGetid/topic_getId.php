<?php 
include 'connect.php';
if(isset($_GET['id'])){
    $id = $_GET['id'];
    //echo $id;
    $query = mysqli_query($con,"select * from topic where id = '$id'");
    $row = mysqli_fetch_assoc($query);
    $name = $row['topic_name'];
    $embed = $row['topic_embed'];
    $article = $row['topic_article'];  
}
else{
    header('location:viewtopic.php');
}

?>