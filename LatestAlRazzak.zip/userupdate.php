    



<?php 
    include 'phpGetid/user_getId.php';
    ob_start();
    include_once 'connect.php';
    if(!isset($_SESSION['user']['email']))
    {
        header('location:login.php');
    }
    
    ?>



    <?php
    include_once 'includeFile/header.php';
    ch_title("Update User");
    include_once 'includeFile/admin_navbar.php';
    ?>

    <section id="mu-contact" style="background-color: white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mu-contact-area">
                        <!-- start title -->
                        <div class="mu-title">
                            <h2>Add Users</h2>
                        </div>
                        <!-- end title -->
                        <!-- start contact content -->
                    
                        <div class="mu-contact-content" >           
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mu-contact-left" >
                                        <form class="contactform" method="post" action="">
                                            <?php 
                                            if(@$_GET['response'] != ''){
                                        echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                    <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                                </div>';
                                            }

                                            ?>
                                            <p class="comment-form-author">
                                                <label for="username">Username <span class="required">*</span></label>
                                                <input type="text"   value="<?php echo $username;?>" name="username">
                                            
                                            </p>
                                            <p class="comment-form-author">
                                                <label for="email">Email <span class="required">*</span></label>
                                                <input type="email" value="<?php echo $email;?>" name="email">
                                            
                                            </p>
                                            <p class="comment-form-email">
                                                <label for="role"> Role <span class="required">*</span></label>
                                                <input type="text" name="role" value="<?php echo $role;?>" readonly>
                                            </p>
                                            <p class="comment-form-email">
                                                <label for="changerole">Change Role <span class="required">*</span></label>
                                                <select class="form-control" name="changerole" id="changerole" onchange="ck_type();">
                                                    <option value=""></option>
                                                    <option value="subadmin">Sub Admin</option>
                                                    <option value="editor">Editor</option>
                                                    <option value="jobeditor">Job Editor</option>
                                                    <option value="neweditor">News Editor</option>
                                                </select>
                                            </p>
                                            
                                      
                                            <p class="form-submit">
                                                <input type="submit" value="Add" class="mu-post-btn" name="submit">
                                            </p> 
                                                
                                        </form>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <!-- end contact content -->
                </div>
            </div>
        </div>
        
    </section>  
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(e){
            $('#assignacademic').on('change', function(e){
                //console.log(e);
                var aca_id = e.target.value;
                //console.log(aca_id);
                $.get('ajax/userServer.php?id='+aca_id, function(data){
                   // console.log(data);
                    var result = JSON.parse(data);
                    //var str = '';
                    //console.log(result);
                    $('#assignsubject').empty();  
                    for(var i=0 ;i<result.length ; i++ ){
                        //console.log(result[i].id);
                        // if(result[i].selected){
                        //     str +=result[i].value + ',';
                        // }
                        $('#assignsubject').append('<option value = "'+result[i].id+'">'+result[i].subject_name+'</option>');
                        $('.selectpicker').selectpicker('refresh');    
                    }
                });
            });
        });
        function ck_type(){
            //alert('tested');
            var user_type = document.getElementById('changerole').value;
            var assignacademic = document.getElementById('assignacademic');
            var assignsubject = document.getElementById('assignsubject');
            if (user_type == 'editor') {
                assignacademic.disabled = false;
                assignsubject.disabled = false;
            }   
            else{
                assignacademic.disabled = true;
                assignsubject.disabled = true;
                assignacademic.value = '';
                $('.selectpicker option:selected').remove();
                $('.selectpicker').selectpicker('refresh');
            }
        }
    </script>

    <?php
    include('includeFile/footer.php');
    ?>


<?php
    include 'phpScript/update_user_script.php';
?>
    

