<?php 
include_once 'connect.php';
if(!isset($_SESSION['user']['email']))
{
    header('location:login.php');
}
    
?>




<?php
include_once 'includeFile/header.php';
ch_title("Add Moke");
include_once 'includeFile/admin_navbar.php';
?>

<section id="mu-contact" style="background-color: white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mu-contact-area">
                    <!-- start title -->
                    <div class="mu-title">
                        <h2>Add Moke</h2>
                    </div>
                    <!-- end title -->
                    <!-- start contact content -->
                
                    <div class="mu-contact-content" >           
                        <div class="row">
                            <div class="col-md-6">
                            <div class="mu-contact-left" >
                                    <form class="contactform" method="post" action="phpScript/moke_script.php" >
                                        <?php 
                                        if(@$_GET['response'] != ''){
                                             echo '  <div class="alert alert-'.@$_GET['class'].'">
                                                <strong>'.ucfirst(@$_GET['response']).'!</strong> '.@$_GET['message'].'
                                            </div>';
                                        }
                                            $timezone = "Asia/Karachi";
                                            date_default_timezone_set($timezone);
                                            $today = date("d/m/y h:i:sa");
                                        ?>
                                        
                                         <p class="comment-form-author">
                                            <label for="name">Job Title <span class="required">*</span></label>
                                            <input type="text"  size="30" value="" name="job_title">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="date">Date <span class="required">*</span></label>
                                            <input type="text"   value="<?php echo $today; ?>" name="date">
                                        </p>
                                        <p class="comment-form-author">
                                            <label for="time">Date <span class="required">*</span></label>
                                            <input type="text"   value="" name="time">
                                        </p>
                                        
                                        <p class="form-submit">
                                            <input type="submit" value="Next" class="mu-post-btn" name="submit">
                                        </p> 
                                            
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- end contact content -->
            </div>
        </div>
    </div>
    
</section>




<?php
include('includeFile/footer.php')
?>